import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { FileText, Copy, Bookmark, Check, Trash2, RotateCcw, Sparkles } from 'lucide-react';
import { copyToClipboard } from '../../utils/formatters';

const STOP_WORDS = new Set([
  'a', 'about', 'above', 'after', 'again', 'against', 'all', 'am', 'an', 'and', 'any', 'are', 'aren',
  'as', 'at', 'be', 'because', 'been', 'before', 'being', 'below', 'between', 'both', 'but', 'by',
  'can', 'could', 'did', 'do', 'does', 'doing', 'down', 'during', 'each', 'few', 'for', 'from',
  'further', 'had', 'has', 'have', 'having', 'he', 'her', 'here', 'hers', 'herself', 'him', 'himself',
  'his', 'how', 'i', 'if', 'in', 'into', 'is', 'isn', 'it', 'its', 'itself', 'just', 'me', 'more',
  'most', 'my', 'myself', 'no', 'nor', 'not', 'now', 'of', 'off', 'on', 'once', 'only', 'or', 'other',
  'our', 'ours', 'ourselves', 'out', 'over', 'own', 'same', 'so', 'some', 'such', 'than', 'that',
  'the', 'their', 'theirs', 'them', 'themselves', 'then', 'there', 'these', 'they', 'this', 'those',
  'through', 'to', 'too', 'under', 'until', 'up', 'very', 'was', 'wasn', 'we', 'were', 'weren', 'what',
  'when', 'where', 'which', 'while', 'who', 'whom', 'why', 'with', 'would', 'you', 'your', 'yours',
  'yourself', 'yourselves'
]);

const SAMPLE_TEXT = `Calculators and precision tools have transformed how modern professionals analyze figures, assess loan commitments, and plan milestones. By verifying numerical models client-side with zero network latency, users enjoy uncompromising data privacy and instantaneous feedback.

Whether analyzing complex compound interest schedules, calculating exact chronological ages down to individual seconds, or verifying sales tax brackets across jurisdictions, computational clarity empowers confident decisions.`;

export const WordCounter: React.FC = () => {
  const { addHistory, showToast } = useCalc();
  const [text, setText] = useState<string>(SAMPLE_TEXT);
  const [filterStopWords, setFilterStopWords] = useState<boolean>(true);
  const [copied, setCopied] = useState(false);

  const stats = useMemo(() => {
    const raw = text;
    const trimmed = raw.trim();

    // Characters
    const charsWithSpaces = raw.length;
    const charsWithoutSpaces = raw.replace(/\s/g, '').length;

    // Words
    const wordsArray = trimmed ? trimmed.split(/\s+/).filter(Boolean) : [];
    const wordCount = wordsArray.length;

    // Sentences
    const sentences = trimmed
      ? trimmed.split(/[.!?]+/).filter((s) => s.trim().length > 0)
      : [];
    const sentenceCount = sentences.length;

    // Paragraphs
    const paragraphs = raw
      ? raw.split(/\n+/).filter((p) => p.trim().length > 0)
      : [];
    const paragraphCount = paragraphs.length;

    // Reading & Speaking times
    const readingTimeMinutes = Math.ceil(wordCount / 200); // 200 wpm
    const speakingTimeMinutes = Math.ceil(wordCount / 130); // 130 wpm

    // Keyword density
    const frequencyMap: Record<string, number> = {};
    for (const w of wordsArray) {
      const cleanWord = w.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (cleanWord.length > 1) {
        if (filterStopWords && STOP_WORDS.has(cleanWord)) continue;
        frequencyMap[cleanWord] = (frequencyMap[cleanWord] || 0) + 1;
      }
    }

    const sortedKeywords = Object.entries(frequencyMap)
      .map(([word, count]) => ({
        word,
        count,
        density: wordCount > 0 ? (count / wordCount) * 100 : 0,
      }))
      .sort((a, b) => b.count - a.count)
      .slice(0, 10);

    return {
      wordCount,
      charsWithSpaces,
      charsWithoutSpaces,
      sentenceCount,
      paragraphCount,
      readingTimeMinutes,
      speakingTimeMinutes,
      sortedKeywords,
    };
  }, [text, filterStopWords]);

  // Text Case Transformations
  const transformCase = (type: 'upper' | 'lower' | 'title' | 'sentence' | 'cleanSpaces') => {
    if (!text) return;
    if (type === 'upper') setText(text.toUpperCase());
    if (type === 'lower') setText(text.toLowerCase());
    if (type === 'cleanSpaces') setText(text.replace(/\s+/g, ' ').trim());
    if (type === 'sentence') {
      const transformed = text.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => c.toUpperCase());
      setText(transformed);
    }
    if (type === 'title') {
      const transformed = text.toLowerCase().replace(/\b(\w)/g, (c) => c.toUpperCase());
      setText(transformed);
    }
    showToast('Text converted');
  };

  const handleCopyText = async () => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Text copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveHistory = () => {
    addHistory({
      calculatorId: 'word-counter',
      calculatorName: 'Word Counter',
      summary: `${stats.wordCount.toLocaleString()} Words · ${stats.charsWithSpaces.toLocaleString()} Chars`,
      details: `${stats.sentenceCount} Sentences · ${stats.paragraphCount} Paragraphs · ~${stats.readingTimeMinutes}m read`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Word Counter &amp; Text Analyzer</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Real-time Text Metrics</span>
          <span aria-hidden="true">·</span>
          <span>Reading &amp; Speaking Time</span>
          <span aria-hidden="true">·</span>
          <span>Keyword Density &amp; Case Converters</span>
        </div>
      </div>

      {/* Top Stat Ribbon */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {[
          { label: 'Words', value: stats.wordCount.toLocaleString() },
          { label: 'Characters', value: stats.charsWithSpaces.toLocaleString() },
          { label: 'No Spaces', value: stats.charsWithoutSpaces.toLocaleString() },
          { label: 'Sentences', value: stats.sentenceCount.toLocaleString() },
          { label: 'Paragraphs', value: stats.paragraphCount.toLocaleString() },
          { label: 'Reading Time', value: `~${stats.readingTimeMinutes} min` },
        ].map((item) => (
          <div key={item.label} className="bg-white p-3.5 rounded-xl border border-slate-200/90 text-center">
            <div className="text-[11px] font-medium text-slate-400">{item.label}</div>
            <div className="text-xl font-bold font-mono tabular-nums text-slate-900 mt-0.5 truncate">
              {item.value}
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Text Input Area */}
        <div className="lg:col-span-8 bg-white rounded-xl border border-slate-200/90 p-5 space-y-4 shadow-xs">
          {/* Action Toolbar */}
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-slate-100">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[11px] text-slate-400 mr-1">Case:</span>
              <button
                type="button"
                onClick={() => transformCase('sentence')}
                className="px-2 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
              >
                Sentence case
              </button>
              <button
                type="button"
                onClick={() => transformCase('title')}
                className="px-2 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
              >
                Title Case
              </button>
              <button
                type="button"
                onClick={() => transformCase('upper')}
                className="px-2 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
              >
                UPPER
              </button>
              <button
                type="button"
                onClick={() => transformCase('lower')}
                className="px-2 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
              >
                lower
              </button>
              <button
                type="button"
                onClick={() => transformCase('cleanSpaces')}
                className="px-2 py-1 text-xs font-medium text-slate-700 bg-slate-100 hover:bg-slate-200 rounded transition-colors"
              >
                Clean Spaces
              </button>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setText('')}
                className="p-1.5 text-slate-400 hover:text-rose-600 rounded hover:bg-rose-50 transition-colors"
                title="Clear text"
              >
                <Trash2 className="w-4 h-4" />
              </button>
              <button
                type="button"
                onClick={() => setText(SAMPLE_TEXT)}
                className="p-1.5 text-slate-400 hover:text-indigo-600 rounded hover:bg-indigo-50 transition-colors"
                title="Reset sample text"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Textarea */}
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Type or paste your text here..."
            rows={12}
            className="w-full p-4 text-sm text-slate-900 placeholder-slate-400 bg-slate-50/50 border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all resize-y leading-relaxed font-sans"
          />

          {/* Text footer actions */}
          <div className="flex items-center justify-between pt-2">
            <span className="text-xs text-slate-400 font-mono">
              Speaking time: ~{stats.speakingTimeMinutes} min (@ 130 WPM)
            </span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyText}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy Text'}</span>
              </button>
              <button
                onClick={handleSaveHistory}
                className="px-3 py-1.5 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center gap-1.5 transition-colors"
              >
                <Bookmark className="w-3.5 h-3.5" />
                <span>Save</span>
              </button>
            </div>
          </div>
        </div>

        {/* Right: Keyword Density Analyzer */}
        <div className="lg:col-span-4 bg-white rounded-xl border border-slate-200/90 p-5 space-y-4 shadow-xs">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-800">
              Keyword Density
            </h3>
            <label className="flex items-center gap-1.5 text-[11px] text-slate-500 cursor-pointer">
              <input
                type="checkbox"
                checked={filterStopWords}
                onChange={(e) => setFilterStopWords(e.target.checked)}
                className="w-3.5 h-3.5 text-indigo-600 rounded border-slate-300"
              />
              <span>Filter Stop Words</span>
            </label>
          </div>

          {stats.sortedKeywords.length === 0 ? (
            <div className="text-center py-8 text-xs text-slate-400">
              Start typing to inspect word frequencies
            </div>
          ) : (
            <div className="space-y-2">
              {stats.sortedKeywords.map((item) => (
                <div key={item.word} className="space-y-1">
                  <div className="flex justify-between text-xs">
                    <span className="font-medium text-slate-700">{item.word}</span>
                    <span className="font-mono text-slate-500">
                      {item.count} ({item.density.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="h-1.5 w-full bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full"
                      style={{ width: `${Math.min(item.density * 5, 100)}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
