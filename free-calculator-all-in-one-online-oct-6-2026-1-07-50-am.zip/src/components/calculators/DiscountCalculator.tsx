import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Tag, Copy, Bookmark, Check, Plus, ShoppingBag } from 'lucide-react';
import { formatCurrency, formatNumber, copyToClipboard } from '../../utils/formatters';

export const DiscountCalculator: React.FC = () => {
  const { currency, addHistory, showToast } = useCalc();
  const [activeSubTab, setActiveSubTab] = useState<'standard' | 'bogo'>('standard');

  // Standard Discount states
  const [originalPrice, setOriginalPrice] = useState<string>('120');
  const [discountType, setDiscountType] = useState<'percent' | 'fixed'>('percent');
  const [discountValue, setDiscountValue] = useState<string>('25');
  
  // Extra stacked discount
  const [hasExtraDiscount, setHasExtraDiscount] = useState<boolean>(true);
  const [extraType, setExtraType] = useState<'percent' | 'fixed'>('percent');
  const [extraValue, setExtraValue] = useState<string>('10');

  // Tax
  const [taxRate, setTaxRate] = useState<string>('8.25');
  const [quantity, setQuantity] = useState<string>('1');

  // BOGO states
  const [bogoBuyQty, setBogoBuyQty] = useState<string>('1');
  const [bogoGetQty, setBogoGetQty] = useState<string>('1');
  const [bogoGetDiscount, setBogoGetDiscount] = useState<string>('100'); // 100% free or 50% off
  const [bogoItemPrice, setBogoItemPrice] = useState<string>('40');

  const [copied, setCopied] = useState(false);

  // Standard Discount Calculation
  const standardResults = useMemo(() => {
    const price = parseFloat(originalPrice) || 0;
    const qty = Math.max(1, parseInt(quantity) || 1);
    const tax = parseFloat(taxRate) || 0;

    let discount1Amount = 0;
    const dVal = parseFloat(discountValue) || 0;

    if (discountType === 'percent') {
      discount1Amount = (dVal / 100) * price;
    } else {
      discount1Amount = Math.min(price, dVal);
    }
    const afterDisc1 = Math.max(0, price - discount1Amount);

    let discount2Amount = 0;
    if (hasExtraDiscount) {
      const eVal = parseFloat(extraValue) || 0;
      if (extraType === 'percent') {
        discount2Amount = (eVal / 100) * afterDisc1;
      } else {
        discount2Amount = Math.min(afterDisc1, eVal);
      }
    }
    const finalUnitPriceBeforeTax = Math.max(0, afterDisc1 - discount2Amount);
    const totalDiscountPerUnit = discount1Amount + discount2Amount;
    const effectiveDiscountPercent = price > 0 ? (totalDiscountPerUnit / price) * 100 : 0;

    // Totals for quantity
    const subtotalBeforeTax = finalUnitPriceBeforeTax * qty;
    const totalSavings = totalDiscountPerUnit * qty;
    const taxAmount = (tax / 100) * subtotalBeforeTax;
    const finalTotalWithTax = subtotalBeforeTax + taxAmount;
    const totalOriginal = price * qty;

    return {
      price,
      qty,
      discount1Amount,
      discount2Amount,
      totalDiscountPerUnit,
      effectiveDiscountPercent,
      finalUnitPriceBeforeTax,
      subtotalBeforeTax,
      totalSavings,
      taxAmount,
      finalTotalWithTax,
      totalOriginal,
    };
  }, [originalPrice, discountType, discountValue, hasExtraDiscount, extraType, extraValue, taxRate, quantity]);

  // BOGO Calculation
  const bogoResults = useMemo(() => {
    const buy = parseInt(bogoBuyQty) || 1;
    const get = parseInt(bogoGetQty) || 1;
    const disc = parseFloat(bogoGetDiscount) || 100;
    const price = parseFloat(bogoItemPrice) || 0;

    const totalItems = buy + get;
    const normalPrice = totalItems * price;
    const discountedItemCost = price * (1 - disc / 100);
    const totalPaid = (buy * price) + (get * discountedItemCost);
    const savings = normalPrice - totalPaid;
    const effectiveDiscount = normalPrice > 0 ? (savings / normalPrice) * 100 : 0;
    const costPerItem = totalItems > 0 ? totalPaid / totalItems : 0;

    return {
      totalItems,
      normalPrice,
      totalPaid,
      savings,
      effectiveDiscount,
      costPerItem,
    };
  }, [bogoBuyQty, bogoGetQty, bogoGetDiscount, bogoItemPrice]);

  const handleCopy = async (text: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Discount summary copied');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveStandardHistory = () => {
    addHistory({
      calculatorId: 'discount',
      calculatorName: 'Discount Calculator',
      summary: `Final: ${formatCurrency(standardResults.finalTotalWithTax, currency)} (Saved ${formatCurrency(standardResults.totalSavings, currency)})`,
      details: `Original: ${formatCurrency(standardResults.totalOriginal, currency)} · Discount: ${formatNumber(standardResults.effectiveDiscountPercent, 1)}% off · Tax: ${formatCurrency(standardResults.taxAmount, currency)}`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Discount Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Sale & Clearance Math</span>
          <span aria-hidden="true">·</span>
          <span>Stacked Coupons</span>
          <span aria-hidden="true">·</span>
          <span>BOGO Deals</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl w-fit">
        <button
          onClick={() => setActiveSubTab('standard')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeSubTab === 'standard' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
          }`}
        >
          Standard & Stacked Coupon
        </button>
        <button
          onClick={() => setActiveSubTab('bogo')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            activeSubTab === 'bogo' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
          }`}
        >
          BOGO & Bundle Deal
        </button>
      </div>

      {activeSubTab === 'standard' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left: Inputs */}
          <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
            {/* Original Price */}
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
                Original Price
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value)}
                  className="w-full pl-8 pr-4 py-2.5 text-base font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
                <span className="absolute left-3 top-2.5 text-slate-400 font-mono text-sm">$</span>
              </div>
            </div>

            {/* Primary Discount */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  Primary Discount
                </label>
                <div className="flex gap-1 text-xs">
                  <button
                    type="button"
                    onClick={() => setDiscountType('percent')}
                    className={`px-2 py-0.5 rounded font-medium ${
                      discountType === 'percent' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-500'
                    }`}
                  >
                    % Off
                  </button>
                  <button
                    type="button"
                    onClick={() => setDiscountType('fixed')}
                    className={`px-2 py-0.5 rounded font-medium ${
                      discountType === 'fixed' ? 'bg-indigo-100 text-indigo-700' : 'text-slate-500'
                    }`}
                  >
                    Fixed Off
                  </button>
                </div>
              </div>

              <div className="relative">
                <input
                  type="number"
                  step="any"
                  value={discountValue}
                  onChange={(e) => setDiscountValue(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
                <span className="absolute right-3 top-2.5 text-slate-400 font-mono text-sm">
                  {discountType === 'percent' ? '%' : '$'}
                </span>
              </div>

              {/* Quick % buttons */}
              {discountType === 'percent' && (
                <div className="flex items-center gap-1.5 mt-2.5 flex-wrap">
                  <span className="text-[11px] text-slate-400">Quick:</span>
                  {[10, 15, 20, 25, 30, 40, 50, 70].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => setDiscountValue(pct.toString())}
                      className="px-2 py-0.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded text-[11px] font-mono transition-colors"
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Extra Stacked Coupon Toggle */}
            <div className="pt-2 border-t border-slate-100">
              <label className="flex items-center gap-2 cursor-pointer mb-2">
                <input
                  type="checkbox"
                  checked={hasExtraDiscount}
                  onChange={(e) => setHasExtraDiscount(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                />
                <span className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                  Apply Extra Stacked Coupon / Member Promo
                </span>
              </label>

              {hasExtraDiscount && (
                <div className="pl-6 space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="number"
                      step="any"
                      value={extraValue}
                      onChange={(e) => setExtraValue(e.target.value)}
                      placeholder="e.g. 10"
                      className="w-32 px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                    />
                    <select
                      value={extraType}
                      onChange={(e) => setExtraType(e.target.value as any)}
                      className="px-3 py-2 text-xs font-medium text-slate-700 bg-slate-100 border border-slate-300 rounded-lg focus:outline-none"
                    >
                      <option value="percent">% Additional Off</option>
                      <option value="fixed">$ Additional Off</option>
                    </select>
                  </div>
                  <p className="text-[11px] text-slate-400">
                    Stacked discounts are applied sequentially onto the discounted subtotal.
                  </p>
                </div>
              )}
            </div>

            {/* Sales Tax & Quantity */}
            <div className="grid grid-cols-2 gap-4 pt-2 border-t border-slate-100">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Sales Tax / VAT (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={taxRate}
                    onChange={(e) => setTaxRate(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                  />
                  <span className="absolute right-3 top-2 text-slate-400 text-xs font-mono">%</span>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Quantity
                </label>
                <input
                  type="number"
                  min="1"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                />
              </div>
            </div>
          </div>

          {/* Right: Results Breakdown */}
          <div className="lg:col-span-5 space-y-4">
            <div className="bg-gradient-to-br from-indigo-50/80 to-white rounded-xl border border-indigo-100 p-6 space-y-5">
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
                  Final Checkout Price
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900">
                  {formatCurrency(standardResults.finalTotalWithTax, currency)}
                </div>
                {standardResults.qty > 1 && (
                  <div className="text-xs text-slate-500 font-mono mt-1">
                    {formatCurrency(standardResults.finalUnitPriceBeforeTax, currency)} per item (before tax)
                  </div>
                )}
              </div>

              {/* Savings Highlight */}
              <div className="p-3.5 bg-emerald-50 border border-emerald-200/80 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs font-semibold text-emerald-800">Total Savings</div>
                  <div className="text-xl font-bold font-mono text-emerald-700 mt-0.5">
                    {formatCurrency(standardResults.totalSavings, currency)}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-emerald-800 font-medium">Effective Discount</div>
                  <div className="text-lg font-bold font-mono text-emerald-700">
                    {formatNumber(standardResults.effectiveDiscountPercent, 1)}% Off
                  </div>
                </div>
              </div>

              {/* Itemized breakdown table */}
              <div className="text-xs space-y-2 pt-2 border-t border-slate-200/80">
                <div className="flex justify-between text-slate-500">
                  <span>Original Total ({standardResults.qty} item{standardResults.qty > 1 ? 's' : ''}):</span>
                  <span className="font-mono line-through text-slate-400">
                    {formatCurrency(standardResults.totalOriginal, currency)}
                  </span>
                </div>
                <div className="flex justify-between text-emerald-600 font-medium">
                  <span>Primary Discount:</span>
                  <span className="font-mono">
                    -{formatCurrency(standardResults.discount1Amount * standardResults.qty, currency)}
                  </span>
                </div>
                {hasExtraDiscount && standardResults.discount2Amount > 0 && (
                  <div className="flex justify-between text-emerald-600 font-medium">
                    <span>Stacked Coupon Discount:</span>
                    <span className="font-mono">
                      -{formatCurrency(standardResults.discount2Amount * standardResults.qty, currency)}
                    </span>
                  </div>
                )}
                {parseFloat(taxRate) > 0 && (
                  <div className="flex justify-between text-slate-600">
                    <span>Estimated Sales Tax ({taxRate}%):</span>
                    <span className="font-mono">+{formatCurrency(standardResults.taxAmount, currency)}</span>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center gap-2 pt-2">
                <button
                  onClick={() =>
                    handleCopy(
                      `Original: ${formatCurrency(standardResults.totalOriginal, currency)}\n` +
                      `Final: ${formatCurrency(standardResults.finalTotalWithTax, currency)}\n` +
                      `Saved: ${formatCurrency(standardResults.totalSavings, currency)} (${formatNumber(standardResults.effectiveDiscountPercent, 1)}% off)`
                    )
                  }
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg flex items-center justify-center gap-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Breakdown'}</span>
                </button>
                <button
                  onClick={handleSaveStandardHistory}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center justify-center gap-1.5"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  <span>Save</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* BOGO Calculator View */
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
          <div className="max-w-2xl space-y-5">
            <h2 className="text-base font-semibold text-slate-900">Buy X Get Y Deal Calculator</h2>

            <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Buy Quantity</label>
                <input
                  type="number"
                  min="1"
                  value={bogoBuyQty}
                  onChange={(e) => setBogoBuyQty(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Get Quantity</label>
                <input
                  type="number"
                  min="1"
                  value={bogoGetQty}
                  onChange={(e) => setBogoGetQty(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Discount on &apos;Get&apos; (%)</label>
                <input
                  type="number"
                  value={bogoGetDiscount}
                  onChange={(e) => setBogoGetDiscount(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg"
                />
                <span className="text-[10px] text-slate-400">100 = Free, 50 = Half off</span>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">Price Per Item ($)</label>
                <input
                  type="number"
                  step="any"
                  value={bogoItemPrice}
                  onChange={(e) => setBogoItemPrice(e.target.value)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>
            </div>

            {/* BOGO Results Banner */}
            <div className="p-5 bg-indigo-50/70 border border-indigo-100 rounded-xl grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
              <div>
                <div className="text-[11px] text-slate-500 font-medium">Total Items</div>
                <div className="text-xl font-bold font-mono text-slate-900 mt-0.5">{bogoResults.totalItems}</div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 font-medium">Total Price Paid</div>
                <div className="text-xl font-bold font-mono text-indigo-700 mt-0.5">
                  {formatCurrency(bogoResults.totalPaid, currency)}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 font-medium">Real Price / Item</div>
                <div className="text-xl font-bold font-mono text-slate-900 mt-0.5">
                  {formatCurrency(bogoResults.costPerItem, currency)}
                </div>
              </div>
              <div>
                <div className="text-[11px] text-slate-500 font-medium">Effective Savings</div>
                <div className="text-xl font-bold font-mono text-emerald-600 mt-0.5">
                  {formatNumber(bogoResults.effectiveDiscount, 1)}% Off
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
