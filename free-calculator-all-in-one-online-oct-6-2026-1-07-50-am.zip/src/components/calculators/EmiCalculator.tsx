import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Calculator, Copy, Bookmark, Check, Layers } from 'lucide-react';
import { formatCurrency, formatNumber, copyToClipboard } from '../../utils/formatters';

interface Preset {
  name: string;
  amount: number;
  rate: number;
  tenureYears: number;
}

const LOAN_PRESETS: Preset[] = [
  { name: 'Home Loan', amount: 200000, rate: 8.5, tenureYears: 20 },
  { name: 'Car Loan', amount: 25000, rate: 9.0, tenureYears: 5 },
  { name: 'Personal Loan', amount: 10000, rate: 12.5, tenureYears: 3 },
  { name: 'Education Loan', amount: 35000, rate: 10.0, tenureYears: 7 },
];

export const EmiCalculator: React.FC = () => {
  const { currency, addHistory, showToast } = useCalc();

  const [principal, setPrincipal] = useState<number>(100000);
  const [annualRate, setAnnualRate] = useState<number>(8.5);
  const [tenureType, setTenureType] = useState<'years' | 'months'>('years');
  const [tenureValue, setTenureValue] = useState<number>(15);
  const [showSchedule, setShowSchedule] = useState<boolean>(false);
  const [copied, setCopied] = useState(false);

  const applyPreset = (preset: Preset) => {
    setPrincipal(preset.amount);
    setAnnualRate(preset.rate);
    setTenureType('years');
    setTenureValue(preset.tenureYears);
  };

  const results = useMemo(() => {
    const P = principal;
    const r = annualRate / 12 / 100; // Monthly interest rate
    const n = tenureType === 'years' ? tenureValue * 12 : tenureValue; // Total months

    if (P <= 0 || r <= 0 || n <= 0) return null;

    // EMI formula: E = P * r * (1 + r)^n / ((1 + r)^n - 1)
    const emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = emi * n;
    const totalInterest = totalPayment - P;
    const principalPercent = (P / totalPayment) * 100;
    const interestPercent = (totalInterest / totalPayment) * 100;

    // Generate yearly schedule
    const yearlySchedule: Array<{
      year: number;
      openingBalance: number;
      yearlyPrincipal: number;
      yearlyInterest: number;
      totalPayment: number;
      closingBalance: number;
    }> = [];

    let currentBalance = P;
    const totalYears = Math.ceil(n / 12);

    for (let yr = 1; yr <= totalYears; yr++) {
      const yearOpening = currentBalance;
      let yrPrincipal = 0;
      let yrInterest = 0;

      for (let m = 1; m <= 12; m++) {
        if (currentBalance <= 0) break;
        const monthInterest = currentBalance * r;
        const monthPrincipal = Math.min(currentBalance, emi - monthInterest);

        yrInterest += monthInterest;
        yrPrincipal += monthPrincipal;
        currentBalance -= monthPrincipal;
      }

      yearlySchedule.push({
        year: yr,
        openingBalance: yearOpening,
        yearlyPrincipal: yrPrincipal,
        yearlyInterest: yrInterest,
        totalPayment: yrPrincipal + yrInterest,
        closingBalance: Math.max(0, currentBalance),
      });

      if (currentBalance <= 0) break;
    }

    return {
      emi,
      totalPayment,
      totalInterest,
      principalPercent,
      interestPercent,
      months: n,
      yearlySchedule,
    };
  }, [principal, annualRate, tenureType, tenureValue]);

  const handleCopy = async () => {
    if (!results) return;
    const text = `Monthly EMI: ${formatCurrency(results.emi, currency)}\n` +
      `Principal: ${formatCurrency(principal, currency)}\n` +
      `Total Interest: ${formatCurrency(results.totalInterest, currency)}\n` +
      `Total Payment: ${formatCurrency(results.totalPayment, currency)}`;
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('EMI breakdown copied');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveHistory = () => {
    if (!results) return;
    addHistory({
      calculatorId: 'emi',
      calculatorName: 'EMI Calculator',
      summary: `EMI: ${formatCurrency(results.emi, currency)}/mo (${formatCurrency(principal, currency)} @ ${annualRate}%)`,
      details: `Total Interest: ${formatCurrency(results.totalInterest, currency)} · Total Payable: ${formatCurrency(results.totalPayment, currency)} · Tenure: ${tenureValue} ${tenureType}`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">EMI Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Equated Monthly Installment</span>
          <span aria-hidden="true">·</span>
          <span>Principal vs Interest Visualizer</span>
          <span aria-hidden="true">·</span>
          <span>Yearly Amortization</span>
        </div>
      </div>

      {/* Preset Buttons */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <span className="text-xs text-slate-400 font-medium">Quick Presets:</span>
        {LOAN_PRESETS.map((p) => (
          <button
            key={p.name}
            onClick={() => applyPreset(p)}
            className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50/50 rounded-lg whitespace-nowrap transition-all shadow-2xs"
          >
            {p.name}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-6">
          {/* Loan Principal Amount */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Loan Amount
              </label>
              <span className="text-base font-bold font-mono text-indigo-700">
                {formatCurrency(principal, currency, 0)}
              </span>
            </div>
            <input
              type="range"
              min="1000"
              max="2000000"
              step="5000"
              value={principal}
              onChange={(e) => setPrincipal(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 mb-2"
            />
            <div className="relative mt-1">
              <input
                type="number"
                value={principal}
                onChange={(e) => setPrincipal(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Interest Rate */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Annual Interest Rate (% p.a.)
              </label>
              <span className="text-base font-bold font-mono text-indigo-700">{annualRate}%</span>
            </div>
            <input
              type="range"
              min="1"
              max="30"
              step="0.1"
              value={annualRate}
              onChange={(e) => setAnnualRate(parseFloat(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 mb-2"
            />
            <div className="relative mt-1">
              <input
                type="number"
                step="0.1"
                value={annualRate}
                onChange={(e) => setAnnualRate(parseFloat(e.target.value) || 0)}
                className="w-full px-3.5 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>

          {/* Loan Tenure */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Loan Tenure
              </label>
              <div className="flex gap-1 text-xs">
                <button
                  type="button"
                  onClick={() => {
                    if (tenureType === 'months') {
                      setTenureType('years');
                      setTenureValue(Math.max(1, Math.round(tenureValue / 12)));
                    }
                  }}
                  className={`px-2.5 py-1 rounded font-semibold ${
                    tenureType === 'years' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  Years
                </button>
                <button
                  type="button"
                  onClick={() => {
                    if (tenureType === 'years') {
                      setTenureType('months');
                      setTenureValue(tenureValue * 12);
                    }
                  }}
                  className={`px-2.5 py-1 rounded font-semibold ${
                    tenureType === 'months' ? 'bg-indigo-600 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  Months
                </button>
              </div>
            </div>

            <input
              type="range"
              min={tenureType === 'years' ? '1' : '6'}
              max={tenureType === 'years' ? '30' : '360'}
              value={tenureValue}
              onChange={(e) => setTenureValue(parseInt(e.target.value) || 1)}
              className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-indigo-600 mb-2"
            />
            <div className="relative mt-1">
              <input
                type="number"
                value={tenureValue}
                onChange={(e) => setTenureValue(parseInt(e.target.value) || 1)}
                className="w-full px-3.5 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
              />
            </div>
          </div>
        </div>

        {/* Right Output Card */}
        <div className="lg:col-span-5 space-y-4">
          {results && (
            <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-5">
              {/* Primary EMI Display */}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
                  Monthly Loan EMI
                </div>
                <div className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900">
                  {formatCurrency(results.emi, currency)}
                </div>
                <div className="text-xs text-slate-400 mt-1">
                  for {results.months} monthly installments
                </div>
              </div>

              {/* Total Payment Details */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
                  <div className="text-slate-400 font-medium">Principal Amount</div>
                  <div className="text-base font-bold font-mono text-slate-800 mt-0.5">
                    {formatCurrency(principal, currency, 0)}
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/70">
                  <div className="text-slate-400 font-medium">Total Interest</div>
                  <div className="text-base font-bold font-mono text-rose-600 mt-0.5">
                    {formatCurrency(results.totalInterest, currency, 0)}
                  </div>
                </div>
              </div>

              {/* Principal vs Interest Ratio Visualizer */}
              <div>
                <div className="flex justify-between text-xs text-slate-500 mb-1.5 font-mono">
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-indigo-600" />
                    Principal ({formatNumber(results.principalPercent, 1)}%)
                  </span>
                  <span className="flex items-center gap-1.5">
                    <span className="w-2.5 h-2.5 rounded-full bg-rose-500" />
                    Interest ({formatNumber(results.interestPercent, 1)}%)
                  </span>
                </div>
                <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex">
                  <div
                    className="bg-indigo-600 transition-all duration-300"
                    style={{ width: `${results.principalPercent}%` }}
                  />
                  <div
                    className="bg-rose-500 transition-all duration-300"
                    style={{ width: `${results.interestPercent}%` }}
                  />
                </div>
              </div>

              {/* Total sum payable */}
              <div className="p-3.5 bg-indigo-50/70 border border-indigo-100 rounded-lg flex items-center justify-between text-xs">
                <span className="font-semibold text-indigo-900">Total Amount Payable:</span>
                <span className="text-base font-bold font-mono text-indigo-950">
                  {formatCurrency(results.totalPayment, currency, 0)}
                </span>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Summary'}</span>
                </button>
                <button
                  onClick={handleSaveHistory}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  <span>Save</span>
                </button>
              </div>

              {/* Toggle Amortization table */}
              <button
                onClick={() => setShowSchedule(!showSchedule)}
                className="w-full text-xs text-indigo-600 hover:text-indigo-800 font-semibold flex items-center justify-center gap-1.5 pt-2"
              >
                <Layers className="w-3.5 h-3.5" />
                <span>{showSchedule ? 'Hide Yearly Schedule' : 'View Yearly Schedule'}</span>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Yearly Amortization Table */}
      {showSchedule && results && (
        <div className="bg-white rounded-xl border border-slate-200/90 overflow-hidden shadow-xs">
          <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex justify-between items-center">
            <h3 className="text-sm font-semibold text-slate-800">Yearly Repayment Amortization Schedule</h3>
            <span className="text-xs text-slate-400 font-mono">Total {results.yearlySchedule.length} Years</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/70 text-slate-600 border-b border-slate-200 font-semibold uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-4">Year</th>
                  <th className="py-2.5 px-4">Opening Balance</th>
                  <th className="py-2.5 px-4">Principal Paid</th>
                  <th className="py-2.5 px-4">Interest Paid</th>
                  <th className="py-2.5 px-4">Total Payment</th>
                  <th className="py-2.5 px-4">Closing Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {results.yearlySchedule.map((row) => (
                  <tr key={row.year} className="hover:bg-slate-50">
                    <td className="py-2.5 px-4 font-bold text-slate-800">Year {row.year}</td>
                    <td className="py-2.5 px-4 text-slate-600">{formatCurrency(row.openingBalance, currency, 0)}</td>
                    <td className="py-2.5 px-4 text-emerald-600 font-medium">
                      {formatCurrency(row.yearlyPrincipal, currency, 0)}
                    </td>
                    <td className="py-2.5 px-4 text-rose-600 font-medium">
                      {formatCurrency(row.yearlyInterest, currency, 0)}
                    </td>
                    <td className="py-2.5 px-4 text-slate-800 font-medium">
                      {formatCurrency(row.totalPayment, currency, 0)}
                    </td>
                    <td className="py-2.5 px-4 text-slate-700">{formatCurrency(row.closingBalance, currency, 0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
