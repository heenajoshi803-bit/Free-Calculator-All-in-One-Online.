import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Landmark, Copy, Bookmark, Check, Download, Zap, TrendingDown } from 'lucide-react';
import { formatCurrency, formatNumber, copyToClipboard } from '../../utils/formatters';

interface AmortizationRow {
  month: number;
  year: number;
  beginningBalance: number;
  emi: number;
  principal: number;
  interest: number;
  extraPayment: number;
  endingBalance: number;
  totalInterestPaidToDate: number;
}

export const LoanCalculator: React.FC = () => {
  const { currency, addHistory, showToast } = useCalc();

  // Basic loan inputs
  const [loanAmount, setLoanAmount] = useState<number>(300000);
  const [interestRate, setInterestRate] = useState<number>(7.5);
  const [tenureYears, setTenureYears] = useState<number>(30);

  // Prepayment options
  const [enablePrepayment, setEnablePrepayment] = useState<boolean>(true);
  const [extraMonthly, setExtraMonthly] = useState<number>(200);
  const [extraYearly, setExtraYearly] = useState<number>(1000);
  const [oneTimeAmount, setOneTimeAmount] = useState<number>(5000);
  const [oneTimeMonth, setOneTimeMonth] = useState<number>(12);

  // Amortization table filter
  const [selectedYearFilter, setSelectedYearFilter] = useState<string>('all');
  const [copied, setCopied] = useState(false);

  // Calculation
  const results = useMemo(() => {
    const P = loanAmount;
    const r = interestRate / 12 / 100;
    const n = tenureYears * 12;

    if (P <= 0 || r <= 0 || n <= 0) return null;

    // Standard base monthly payment
    const standardEmi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const standardTotalPayment = standardEmi * n;
    const standardTotalInterest = standardTotalPayment - P;

    // Simulate accelerated schedule with prepayments
    let balance = P;
    let totalInterestPaid = 0;
    let totalPaymentsPaid = 0;
    const schedule: AmortizationRow[] = [];
    let payoffMonth = 0;

    for (let m = 1; m <= n; m++) {
      if (balance <= 0) break;

      const year = Math.ceil(m / 12);
      const beginningBalance = balance;
      const interest = balance * r;

      // Base principal from EMI
      let regularPrincipal = Math.min(balance, standardEmi - interest);

      // Prepayments
      let extra = 0;
      if (enablePrepayment) {
        extra += extraMonthly;
        if (m % 12 === 0) extra += extraYearly;
        if (m === oneTimeMonth) extra += oneTimeAmount;
      }

      // Cap principal payment at remaining balance
      let totalPrincipal = regularPrincipal + extra;
      if (totalPrincipal > balance) {
        totalPrincipal = balance;
        extra = Math.max(0, balance - regularPrincipal);
      }

      const endingBalance = Math.max(0, balance - totalPrincipal);
      const totalMonthPayment = totalPrincipal + interest;

      totalInterestPaid += interest;
      totalPaymentsPaid += totalMonthPayment;
      balance = endingBalance;
      payoffMonth = m;

      schedule.push({
        month: m,
        year,
        beginningBalance,
        emi: standardEmi,
        principal: totalPrincipal,
        interest,
        extraPayment: extra,
        endingBalance,
        totalInterestPaidToDate: totalInterestPaid,
      });

      if (balance <= 0) break;
    }

    const interestSaved = Math.max(0, standardTotalInterest - totalInterestPaid);
    const monthsSaved = Math.max(0, n - payoffMonth);
    const yearsSaved = Math.floor(monthsSaved / 12);
    const remainingMonthsSaved = monthsSaved % 12;

    return {
      standardEmi,
      standardTotalInterest,
      standardTotalPayment,
      actualPayoffMonths: payoffMonth,
      actualTotalInterest: totalInterestPaid,
      actualTotalPayment: totalPaymentsPaid,
      interestSaved,
      monthsSaved,
      yearsSaved,
      remainingMonthsSaved,
      schedule,
    };
  }, [loanAmount, interestRate, tenureYears, enablePrepayment, extraMonthly, extraYearly, oneTimeAmount, oneTimeMonth]);

  const handleCopy = async () => {
    if (!results) return;
    const text = `Loan Summary: ${formatCurrency(loanAmount, currency)} @ ${interestRate}% for ${tenureYears} yrs\n` +
      `Standard EMI: ${formatCurrency(results.standardEmi, currency)}/mo\n` +
      (enablePrepayment
        ? `With Prepayments:\nPaid off ${results.yearsSaved} yrs, ${results.remainingMonthsSaved} mos earlier!\nInterest Saved: ${formatCurrency(results.interestSaved, currency)}`
        : `Total Interest: ${formatCurrency(results.standardTotalInterest, currency)}`);
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Loan details copied');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveHistory = () => {
    if (!results) return;
    addHistory({
      calculatorId: 'loan',
      calculatorName: 'Loan Calculator',
      summary: `Loan: ${formatCurrency(loanAmount, currency)} @ ${interestRate}% (${tenureYears} yrs)`,
      details: enablePrepayment
        ? `Prepayment saves ${formatCurrency(results.interestSaved, currency)} & ${results.yearsSaved}y ${results.remainingMonthsSaved}m earlier`
        : `Monthly: ${formatCurrency(results.standardEmi, currency)} · Total Interest: ${formatCurrency(results.standardTotalInterest, currency)}`,
    });
    showToast('Saved to Activity Log');
  };

  const exportCSV = () => {
    if (!results) return;
    const headers = ['Month', 'Year', 'Beginning Balance', 'EMI', 'Principal Paid', 'Interest Paid', 'Extra Prepayment', 'Ending Balance'];
    const rows = results.schedule.map((r) => [
      r.month,
      r.year,
      r.beginningBalance.toFixed(2),
      r.emi.toFixed(2),
      r.principal.toFixed(2),
      r.interest.toFixed(2),
      r.extraPayment.toFixed(2),
      r.endingBalance.toFixed(2),
    ]);
    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `Loan_Amortization_${loanAmount}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Downloaded Amortization CSV');
  };

  const filteredSchedule = useMemo(() => {
    if (!results) return [];
    if (selectedYearFilter === 'all') return results.schedule;
    const yr = parseInt(selectedYearFilter);
    return results.schedule.filter((r) => r.year === yr);
  }, [results, selectedYearFilter]);

  const totalYearsInSchedule = results ? Math.ceil(results.actualPayoffMonths / 12) : 0;

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Loan & Prepayment Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Accelerated Payoff Analyzer</span>
          <span aria-hidden="true">·</span>
          <span>Interest Savings</span>
          <span aria-hidden="true">·</span>
          <span>Amortization Schedule with CSV Export</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Loan Amount
              </label>
              <input
                type="number"
                step="1000"
                value={loanAmount}
                onChange={(e) => setLoanAmount(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Interest Rate (%)
              </label>
              <input
                type="number"
                step="0.05"
                value={interestRate}
                onChange={(e) => setInterestRate(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Tenure (Years)
              </label>
              <input
                type="number"
                min="1"
                max="40"
                value={tenureYears}
                onChange={(e) => setTenureYears(parseInt(e.target.value) || 1)}
                className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
              />
            </div>
          </div>

          {/* Prepayment Strategy Panel */}
          <div className="pt-4 border-t border-slate-100 space-y-4">
            <div className="flex items-center justify-between">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={enablePrepayment}
                  onChange={(e) => setEnablePrepayment(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300 focus:ring-indigo-500"
                />
                <span className="text-xs font-bold text-slate-800 uppercase tracking-wider flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-amber-500" />
                  Test Prepayment Strategies
                </span>
              </label>
            </div>

            {enablePrepayment && (
              <div className="p-4 bg-slate-50 rounded-xl border border-slate-200/80 space-y-3.5 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Extra Monthly Payment
                    </label>
                    <input
                      type="number"
                      step="50"
                      value={extraMonthly}
                      onChange={(e) => setExtraMonthly(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 font-mono font-semibold bg-white border border-slate-300 rounded-lg"
                    />
                    <span className="text-[10px] text-slate-400">Added to every regular EMI</span>
                  </div>

                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">
                      Extra Annual Lump Sum
                    </label>
                    <input
                      type="number"
                      step="500"
                      value={extraYearly}
                      onChange={(e) => setExtraYearly(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 font-mono font-semibold bg-white border border-slate-300 rounded-lg"
                    />
                    <span className="text-[10px] text-slate-400">Paid once every 12th month</span>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-200/60 grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">One-Time Lump Sum</label>
                    <input
                      type="number"
                      step="1000"
                      value={oneTimeAmount}
                      onChange={(e) => setOneTimeAmount(parseFloat(e.target.value) || 0)}
                      className="w-full px-3 py-1.5 font-mono font-semibold bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-600 font-semibold mb-1">Paid at Month #</label>
                    <input
                      type="number"
                      min="1"
                      max={tenureYears * 12}
                      value={oneTimeMonth}
                      onChange={(e) => setOneTimeMonth(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-1.5 font-mono font-semibold bg-white border border-slate-300 rounded-lg"
                    />
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Summary */}
        <div className="lg:col-span-5 space-y-4">
          {results && (
            <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-5">
              {/* Highlight Card */}
              {enablePrepayment && results.interestSaved > 0 ? (
                <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-xl space-y-2">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-800 uppercase tracking-wide">
                    <TrendingDown className="w-4 h-4 text-emerald-600" />
                    Prepayment Impact
                  </div>
                  <div className="text-2xl font-bold font-mono text-emerald-700">
                    Saved {formatCurrency(results.interestSaved, currency, 0)}
                  </div>
                  <div className="text-xs text-emerald-800 font-medium">
                    Debt-free <strong>{results.yearsSaved} years &amp; {results.remainingMonthsSaved} months</strong> earlier!
                  </div>
                </div>
              ) : (
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                    Standard Monthly Payment
                  </div>
                  <div className="text-3xl font-extrabold font-mono text-slate-900">
                    {formatCurrency(results.standardEmi, currency)}/mo
                  </div>
                </div>
              )}

              {/* Side-by-side comparison */}
              <div className="text-xs space-y-2.5 pt-1 border-t border-slate-100">
                <div className="flex justify-between text-slate-500">
                  <span>Scheduled Payoff:</span>
                  <span className="font-mono">{tenureYears} Years ({tenureYears * 12} mos)</span>
                </div>
                {enablePrepayment && (
                  <div className="flex justify-between text-indigo-700 font-semibold">
                    <span>New Payoff Time:</span>
                    <span className="font-mono">
                      {Math.floor(results.actualPayoffMonths / 12)} yrs {results.actualPayoffMonths % 12} mos
                    </span>
                  </div>
                )}
                <div className="flex justify-between text-slate-600">
                  <span>Standard Total Interest:</span>
                  <span className="font-mono">{formatCurrency(results.standardTotalInterest, currency, 0)}</span>
                </div>
                {enablePrepayment && (
                  <div className="flex justify-between text-emerald-600 font-semibold">
                    <span>New Total Interest:</span>
                    <span className="font-mono">{formatCurrency(results.actualTotalInterest, currency, 0)}</span>
                  </div>
                )}
                <div className="flex justify-between text-slate-900 font-bold pt-1 border-t border-slate-100">
                  <span>Total Loan Cost:</span>
                  <span className="font-mono">
                    {formatCurrency(enablePrepayment ? results.actualTotalPayment : results.standardTotalPayment, currency, 0)}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center gap-1.5"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={exportCSV}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg flex items-center justify-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5 text-slate-500" />
                  <span>Export CSV</span>
                </button>
                <button
                  onClick={handleSaveHistory}
                  className="px-3 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Amortization Schedule Table */}
      {results && (
        <div className="bg-white rounded-xl border border-slate-200/90 overflow-hidden shadow-xs space-y-2">
          <div className="p-4 border-b border-slate-200 bg-slate-50/50 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-sm font-semibold text-slate-800">Monthly Amortization Schedule</h3>
              <p className="text-xs text-slate-400">Total {results.actualPayoffMonths} payments until $0.00 balance</p>
            </div>

            {/* Filter by year */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-500">Filter Year:</span>
              <select
                value={selectedYearFilter}
                onChange={(e) => setSelectedYearFilter(e.target.value)}
                className="px-2.5 py-1 bg-white border border-slate-200 rounded-md font-mono text-xs focus:outline-none"
              >
                <option value="all">All {totalYearsInSchedule} Years</option>
                {Array.from({ length: totalYearsInSchedule }, (_, i) => i + 1).map((yr) => (
                  <option key={yr} value={yr}>
                    Year {yr}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="overflow-x-auto max-h-96">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100/70 text-slate-600 border-b border-slate-200 font-semibold sticky top-0 uppercase tracking-wider">
                <tr>
                  <th className="py-2.5 px-3">Mo #</th>
                  <th className="py-2.5 px-3">Beg. Balance</th>
                  <th className="py-2.5 px-3">Regular EMI</th>
                  <th className="py-2.5 px-3">Principal</th>
                  <th className="py-2.5 px-3">Interest</th>
                  <th className="py-2.5 px-3">Extra Prepay</th>
                  <th className="py-2.5 px-3">End Balance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 font-mono">
                {filteredSchedule.map((row) => (
                  <tr key={row.month} className="hover:bg-slate-50">
                    <td className="py-2 px-3 font-semibold text-slate-700">M{row.month} (Y{row.year})</td>
                    <td className="py-2 px-3 text-slate-600">{formatCurrency(row.beginningBalance, currency, 0)}</td>
                    <td className="py-2 px-3 text-slate-600">{formatCurrency(row.emi, currency, 0)}</td>
                    <td className="py-2 px-3 text-emerald-600 font-medium">{formatCurrency(row.principal, currency, 0)}</td>
                    <td className="py-2 px-3 text-rose-600 font-medium">{formatCurrency(row.interest, currency, 0)}</td>
                    <td className="py-2 px-3 text-amber-600 font-medium">
                      {row.extraPayment > 0 ? `+${formatCurrency(row.extraPayment, currency, 0)}` : '—'}
                    </td>
                    <td className="py-2 px-3 text-slate-800 font-bold">{formatCurrency(row.endingBalance, currency, 0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
