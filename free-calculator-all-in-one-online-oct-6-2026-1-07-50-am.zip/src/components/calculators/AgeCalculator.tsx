import React, { useState, useMemo, useEffect } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Calendar, Cake, Sparkles, Clock, Copy, Bookmark, Check } from 'lucide-react';
import { copyToClipboard } from '../../utils/formatters';

interface ZodiacInfo {
  sign: string;
  symbol: string;
  element: string;
}

function getZodiac(month: number, day: number): ZodiacInfo {
  // month is 1-indexed (1 = Jan, 12 = Dec)
  if ((month === 3 && day >= 21) || (month === 4 && day <= 19)) return { sign: 'Aries', symbol: '♈', element: 'Fire' };
  if ((month === 4 && day >= 20) || (month === 5 && day <= 20)) return { sign: 'Taurus', symbol: '♉', element: 'Earth' };
  if ((month === 5 && day >= 21) || (month === 6 && day <= 20)) return { sign: 'Gemini', symbol: '♊', element: 'Air' };
  if ((month === 6 && day >= 21) || (month === 7 && day <= 22)) return { sign: 'Cancer', symbol: '♋', element: 'Water' };
  if ((month === 7 && day >= 23) || (month === 8 && day <= 22)) return { sign: 'Leo', symbol: '♌', element: 'Fire' };
  if ((month === 8 && day >= 23) || (month === 9 && day <= 22)) return { sign: 'Virgo', symbol: '♍', element: 'Earth' };
  if ((month === 9 && day >= 23) || (month === 10 && day <= 22)) return { sign: 'Libra', symbol: '♎', element: 'Air' };
  if ((month === 10 && day >= 23) || (month === 11 && day <= 21)) return { sign: 'Scorpio', symbol: '♏', element: 'Water' };
  if ((month === 11 && day >= 22) || (month === 12 && day <= 21)) return { sign: 'Sagittarius', symbol: '♐', element: 'Fire' };
  if ((month === 12 && day >= 22) || (month === 1 && day <= 19)) return { sign: 'Capricorn', symbol: '♑', element: 'Earth' };
  if ((month === 1 && day >= 20) || (month === 2 && day <= 18)) return { sign: 'Aquarius', symbol: '♒', element: 'Air' };
  return { sign: 'Pisces', symbol: '♓', element: 'Water' };
}

const CHINESE_ZODIAC = ['Rat', 'Ox', 'Tiger', 'Rabbit', 'Dragon', 'Snake', 'Horse', 'Goat', 'Monkey', 'Rooster', 'Dog', 'Pig'];

export const AgeCalculator: React.FC = () => {
  const { addHistory, showToast } = useCalc();

  // Default to 25 years ago
  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const defaultDob = useMemo(() => {
    const d = new Date();
    d.setFullYear(d.getFullYear() - 25);
    return d.toISOString().split('T')[0];
  }, []);

  const [dob, setDob] = useState<string>(defaultDob);
  const [targetDate, setTargetDate] = useState<string>(todayStr);
  const [copied, setCopied] = useState(false);

  // Quick preset buttons
  const applyPresetYears = (years: number) => {
    const d = new Date();
    d.setFullYear(d.getFullYear() - years);
    setDob(d.toISOString().split('T')[0]);
  };

  const { error, results } = useMemo(() => {
    if (!dob || !targetDate) return { error: null, results: null };

    const birth = new Date(dob + 'T00:00:00');
    const target = new Date(targetDate + 'T00:00:00');

    if (isNaN(birth.getTime()) || isNaN(target.getTime())) {
      return { error: 'Invalid date entered.', results: null };
    }
    if (birth > target) {
      return { error: 'Birth date cannot be after the comparison date.', results: null };
    }

    let years = target.getFullYear() - birth.getFullYear();
    let months = target.getMonth() - birth.getMonth();
    let days = target.getDate() - birth.getDate();

    if (days < 0) {
      months -= 1;
      // Days in previous month
      const prevMonth = new Date(target.getFullYear(), target.getMonth(), 0);
      days += prevMonth.getDate();
    }

    if (months < 0) {
      years -= 1;
      months += 12;
    }

    // Total units
    const diffMs = target.getTime() - birth.getTime();
    const totalDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    const totalWeeks = Math.floor(totalDays / 7);
    const remainingDaysAfterWeeks = totalDays % 7;
    const totalMonths = years * 12 + months;
    const totalHours = totalDays * 24;
    const totalMinutes = totalHours * 60;
    const totalSeconds = totalMinutes * 60;

    // Day of week born
    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const bornDayName = daysOfWeek[birth.getDay()];

    // Next birthday calculation
    const nextBday = new Date(target.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBday < target) {
      nextBday.setFullYear(target.getFullYear() + 1);
    }
    const daysToNextBday = Math.ceil((nextBday.getTime() - target.getTime()) / (1000 * 60 * 60 * 24));
    const nextBdayDayName = daysOfWeek[nextBday.getDay()];
    const turningAge = years + 1;

    // Half birthday (6 months after birth date)
    const halfBday = new Date(birth.getFullYear(), birth.getMonth() + 6, birth.getDate());
    const halfBdayFormatted = halfBday.toLocaleDateString(undefined, { month: 'long', day: 'numeric' });

    // Zodiac
    const zodiac = getZodiac(birth.getMonth() + 1, birth.getDate());
    const chineseAnimal = CHINESE_ZODIAC[(birth.getFullYear() - 4) % 12];

    // Milestones
    const day10k = new Date(birth.getTime() + 10000 * 24 * 60 * 60 * 1000).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
    const day20k = new Date(birth.getTime() + 20000 * 24 * 60 * 60 * 1000).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
    const age50Date = new Date(birth.getFullYear() + 50, birth.getMonth(), birth.getDate()).toLocaleDateString(undefined, {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });

    return {
      error: null,
      results: {
        years,
        months,
        days,
        totalDays,
        totalWeeks,
        remainingDaysAfterWeeks,
        totalMonths,
        totalHours,
        totalMinutes,
        totalSeconds,
        bornDayName,
        daysToNextBday,
        nextBdayDayName,
        turningAge,
        halfBdayFormatted,
        zodiac,
        chineseAnimal,
        day10k,
        day20k,
        age50Date,
      },
    };
  }, [dob, targetDate]);

  const handleCopySummary = async () => {
    if (!results) return;
    const text = `Age: ${results.years} years, ${results.months} months, ${results.days} days\n` +
      `Total Days: ${results.totalDays.toLocaleString()}\n` +
      `Next Birthday: in ${results.daysToNextBday} days (${results.nextBdayDayName})\n` +
      `Zodiac: ${results.zodiac.sign} (${results.zodiac.element})`;
    
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Age report copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleLogHistory = () => {
    if (!results) return;
    addHistory({
      calculatorId: 'age',
      calculatorName: 'Age Calculator',
      summary: `${results.years} Years, ${results.months} Months, ${results.days} Days`,
      details: `Born: ${dob} (${results.bornDayName}) · Next B-day in ${results.daysToNextBday} days · Total days: ${results.totalDays.toLocaleString()}`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title & Metadata header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Age Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Chronological & Calendar Math</span>
          <span aria-hidden="true">·</span>
          <span>Next Birthday Countdown</span>
          <span aria-hidden="true">·</span>
          <span>Zodiac & Life Milestones</span>
        </div>
      </div>

      {/* Input Form Panel */}
      <div className="bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 shadow-xs space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Date of Birth */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Date of Birth
            </label>
            <div className="relative">
              <input
                type="date"
                value={dob}
                onChange={(e) => setDob(e.target.value)}
                max={targetDate}
                className="w-full px-3.5 py-2.5 text-sm font-medium text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
              />
            </div>
            {/* Quick age presets */}
            <div className="flex items-center gap-1.5 mt-2.5">
              <span className="text-[11px] text-slate-400">Presets:</span>
              {[18, 21, 25, 30, 40, 50].map((yr) => (
                <button
                  key={yr}
                  type="button"
                  onClick={() => applyPresetYears(yr)}
                  className="px-2 py-0.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded text-[11px] transition-colors"
                >
                  {yr}y
                </button>
              ))}
            </div>
          </div>

          {/* Age at the Date of */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Age as of Date
            </label>
            <div className="relative">
              <input
                type="date"
                value={targetDate}
                onChange={(e) => setTargetDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm font-medium text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white transition-all"
              />
            </div>
            <div className="flex items-center gap-2 mt-2.5">
              <button
                type="button"
                onClick={() => setTargetDate(todayStr)}
                className="text-xs text-indigo-600 hover:text-indigo-800 font-medium hover:underline text-[11px]"
              >
                Reset to Today
              </button>
            </div>
          </div>
        </div>

        {error && (
          <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 text-xs rounded-lg">
            {error}
          </div>
        )}
      </div>

      {/* Results View */}
      {results && (
        <div className="space-y-6">
          {/* Primary Result Banner */}
          <div className="bg-gradient-to-br from-indigo-50 via-white to-slate-50 border border-indigo-100 rounded-xl p-6 sm:p-7 relative overflow-hidden">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
                  Exact Age
                </div>
                <div className="flex items-baseline flex-wrap gap-2 text-slate-900">
                  <span className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums tracking-tight">
                    {results.years}
                  </span>
                  <span className="text-base text-slate-600 font-medium mr-2">years</span>

                  <span className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums tracking-tight">
                    {results.months}
                  </span>
                  <span className="text-base text-slate-600 font-medium mr-2">months</span>

                  <span className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums tracking-tight">
                    {results.days}
                  </span>
                  <span className="text-base text-slate-600 font-medium">days</span>
                </div>
                <p className="text-xs text-slate-500 mt-2">
                  Born on a <strong className="text-slate-800">{results.bornDayName}</strong>
                </p>
              </div>

              {/* Action buttons */}
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={handleCopySummary}
                  className="px-3.5 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy'}</span>
                </button>
                <button
                  onClick={handleLogHistory}
                  className="px-3.5 py-2 text-xs font-medium text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg shadow-2xs flex items-center gap-1.5 transition-colors"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  <span>Log Activity</span>
                </button>
              </div>
            </div>
          </div>

          {/* Breakdown in other units grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {[
              { label: 'Total Months', value: results.totalMonths.toLocaleString() },
              { label: 'Total Weeks', value: `${results.totalWeeks.toLocaleString()} wks` },
              { label: 'Total Days', value: results.totalDays.toLocaleString() },
              { label: 'Total Hours', value: results.totalHours.toLocaleString() },
              { label: 'Total Minutes', value: results.totalMinutes.toLocaleString() },
              { label: 'Total Seconds', value: results.totalSeconds.toLocaleString() },
            ].map((stat) => (
              <div
                key={stat.label}
                className="bg-white p-3.5 rounded-lg border border-slate-200/90 text-center"
              >
                <div className="text-[11px] text-slate-400 font-medium">{stat.label}</div>
                <div className="text-sm sm:text-base font-bold font-mono tabular-nums text-slate-800 mt-1 truncate">
                  {stat.value}
                </div>
              </div>
            ))}
          </div>

          {/* Side by side: Next Birthday & Astrological / Milestones */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Next Birthday Card */}
            <div className="bg-white rounded-xl border border-slate-200/90 p-5 space-y-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <Cake className="w-4 h-4 text-indigo-600" />
                <span>Next Birthday Countdown</span>
              </div>
              <div className="p-4 bg-slate-50 rounded-lg border border-slate-200/60">
                <div className="text-xs text-slate-500">Turning Age {results.turningAge} in</div>
                <div className="text-2xl font-bold font-mono tabular-nums text-indigo-600 mt-0.5">
                  {results.daysToNextBday} <span className="text-sm font-normal text-slate-600">days away</span>
                </div>
                <div className="text-xs text-slate-500 mt-2 flex items-center gap-2">
                  <span>Day: <strong className="text-slate-800">{results.nextBdayDayName}</strong></span>
                  <span aria-hidden="true">·</span>
                  <span>Half-Bday: <strong className="text-slate-800">{results.halfBdayFormatted}</strong></span>
                </div>
              </div>
            </div>

            {/* Zodiac & Cultural Milestones Card */}
            <div className="bg-white rounded-xl border border-slate-200/90 p-5 space-y-4">
              <div className="flex items-center gap-2 text-sm font-semibold text-slate-900">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Zodiac & Life Milestones</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                  <div className="text-slate-400">Western Zodiac</div>
                  <div className="font-semibold text-slate-800 mt-0.5 text-sm flex items-center gap-1.5">
                    <span>{results.zodiac.symbol}</span>
                    <span>{results.zodiac.sign}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">{results.zodiac.element} element</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                  <div className="text-slate-400">Chinese Zodiac</div>
                  <div className="font-semibold text-slate-800 mt-0.5 text-sm">
                    {results.chineseAnimal}
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">Lunar Year</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                  <div className="text-slate-400">10,000 Days Milestone</div>
                  <div className="font-mono tabular-nums font-semibold text-slate-800 mt-0.5">
                    {results.day10k}
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                  <div className="text-slate-400">50th Golden Jubilee</div>
                  <div className="font-mono tabular-nums font-semibold text-slate-800 mt-0.5">
                    {results.age50Date}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
