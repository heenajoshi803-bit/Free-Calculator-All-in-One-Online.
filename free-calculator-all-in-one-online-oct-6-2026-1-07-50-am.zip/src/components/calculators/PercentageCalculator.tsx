import React, { useState } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Percent, ArrowRight, Copy, Bookmark, Check } from 'lucide-react';
import { copyToClipboard, formatNumber } from '../../utils/formatters';

type Mode = 'percent-of' | 'is-what-percent' | 'percent-change' | 'original-value' | 'margin-markup';

export const PercentageCalculator: React.FC = () => {
  const { addHistory, showToast } = useCalc();
  const [mode, setMode] = useState<Mode>('percent-of');
  const [copied, setCopied] = useState(false);

  // Mode 1: What is X% of Y?
  const [p1, setP1] = useState<string>('15');
  const [y1, setY1] = useState<string>('240');

  // Mode 2: X is what % of Y?
  const [x2, setX2] = useState<string>('36');
  const [y2, setY2] = useState<string>('120');

  // Mode 3: % Increase/Decrease from X to Y
  const [from3, setFrom3] = useState<string>('50');
  const [to3, setTo3] = useState<string>('75');

  // Mode 4: Value after X% increase/decrease
  const [finalVal4, setFinalVal4] = useState<string>('120');
  const [rate4, setRate4] = useState<string>('20');
  const [type4, setType4] = useState<'increase' | 'decrease'>('increase');

  // Mode 5: Margin & Markup
  const [cost5, setCost5] = useState<string>('80');
  const [sell5, setSell5] = useState<string>('120');

  // Calculation logic
  const calc1 = () => {
    const p = parseFloat(p1);
    const y = parseFloat(y1);
    if (isNaN(p) || isNaN(y)) return null;
    const result = (p / 100) * y;
    return {
      result,
      formula: `(${p} / 100) × ${y} = ${formatNumber(result)}`,
      summary: `${p}% of ${y} = ${formatNumber(result)}`,
    };
  };

  const calc2 = () => {
    const x = parseFloat(x2);
    const y = parseFloat(y2);
    if (isNaN(x) || isNaN(y) || y === 0) return null;
    const result = (x / y) * 100;
    return {
      result,
      formula: `(${x} / ${y}) × 100 = ${formatNumber(result, 2)}%`,
      summary: `${x} is ${formatNumber(result, 2)}% of ${y}`,
    };
  };

  const calc3 = () => {
    const f = parseFloat(from3);
    const t = parseFloat(to3);
    if (isNaN(f) || isNaN(t) || f === 0) return null;
    const diff = t - f;
    const pct = (diff / Math.abs(f)) * 100;
    const isIncrease = diff >= 0;
    return {
      diff,
      pct,
      isIncrease,
      formula: `((${t} - ${f}) / |${f}|) × 100 = ${formatNumber(pct, 2)}%`,
      summary: `${isIncrease ? 'Increase' : 'Decrease'} of ${formatNumber(Math.abs(pct), 2)}% (Diff: ${formatNumber(diff)})`,
    };
  };

  const calc4 = () => {
    const finalVal = parseFloat(finalVal4);
    const r = parseFloat(rate4);
    if (isNaN(finalVal) || isNaN(r)) return null;
    let original = 0;
    if (type4 === 'increase') {
      original = finalVal / (1 + r / 100);
    } else {
      if (r >= 100) return null;
      original = finalVal / (1 - r / 100);
    }
    const diff = finalVal - original;
    return {
      original,
      diff,
      formula: type4 === 'increase'
        ? `${finalVal} / (1 + ${r}/100) = ${formatNumber(original, 2)}`
        : `${finalVal} / (1 - ${r}/100) = ${formatNumber(original, 2)}`,
      summary: `Original Value: ${formatNumber(original, 2)} before ${r}% ${type4}`,
    };
  };

  const calc5 = () => {
    const c = parseFloat(cost5);
    const s = parseFloat(sell5);
    if (isNaN(c) || isNaN(s) || c < 0 || s < 0) return null;
    const profit = s - c;
    const margin = s !== 0 ? (profit / s) * 100 : 0;
    const markup = c !== 0 ? (profit / c) * 100 : 0;
    return {
      profit,
      margin,
      markup,
      summary: `Profit: ${formatNumber(profit)} · Margin: ${formatNumber(margin, 2)}% · Markup: ${formatNumber(markup, 2)}%`,
    };
  };

  const handleCopy = async (text: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveHistory = (summary: string, details: string) => {
    addHistory({
      calculatorId: 'percentage',
      calculatorName: 'Percentage Calculator',
      summary,
      details,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title & Metadata */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Percentage Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>5-in-1 Percentage Suite</span>
          <span aria-hidden="true">·</span>
          <span>Relative Change</span>
          <span aria-hidden="true">·</span>
          <span>Margin & Markup</span>
        </div>
      </div>

      {/* Mode selection tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {[
          { id: 'percent-of', label: 'X% of Y' },
          { id: 'is-what-percent', label: 'X is what % of Y' },
          { id: 'percent-change', label: '% Increase / Decrease' },
          { id: 'original-value', label: 'Original Value' },
          { id: 'margin-markup', label: 'Margin & Markup' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setMode(tab.id as Mode)}
            className={`px-3 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-all cursor-pointer ${
              mode === tab.id
                ? 'bg-white text-indigo-700 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Mode 1: What is X% of Y? */}
      {mode === 'percent-of' && (() => {
        const res = calc1();
        return (
          <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="w-full sm:w-1/3">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Percentage (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={p1}
                    onChange={(e) => setP1(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                  />
                  <span className="absolute right-3 top-2.5 text-slate-400 font-mono text-sm">%</span>
                </div>
              </div>

              <div className="text-slate-400 text-sm font-medium pt-5">of</div>

              <div className="w-full sm:w-1/3">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Total Value (Y)
                </label>
                <input
                  type="number"
                  step="any"
                  value={y1}
                  onChange={(e) => setY1(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>

              <div className="text-slate-400 text-sm font-medium pt-5">=</div>

              <div className="w-full sm:w-1/3 pt-5">
                <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-lg">
                  <div className="text-[11px] text-indigo-700 font-semibold uppercase">Result</div>
                  <div className="text-2xl font-bold font-mono text-indigo-950 truncate">
                    {res ? formatNumber(res.result) : '—'}
                  </div>
                </div>
              </div>
            </div>

            {res && (
              <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                <div className="font-mono text-slate-500">
                  Formula: {res.formula}
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleCopy(res.summary)}
                    className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded transition-colors flex items-center gap-1"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>Copy</span>
                  </button>
                  <button
                    onClick={() => handleSaveHistory(res.summary, res.formula)}
                    className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded transition-colors flex items-center gap-1"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>Save</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* Mode 2: X is what % of Y? */}
      {mode === 'is-what-percent' && (() => {
        const res = calc2();
        return (
          <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              <div className="w-full sm:w-1/3">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Part Value (X)
                </label>
                <input
                  type="number"
                  step="any"
                  value={x2}
                  onChange={(e) => setX2(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>

              <div className="text-slate-400 text-sm font-medium pt-5">is what % of</div>

              <div className="w-full sm:w-1/3">
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Whole Value (Y)
                </label>
                <input
                  type="number"
                  step="any"
                  value={y2}
                  onChange={(e) => setY2(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>

              <div className="text-slate-400 text-sm font-medium pt-5">=</div>

              <div className="w-full sm:w-1/3 pt-5">
                <div className="p-3 bg-indigo-50/70 border border-indigo-100 rounded-lg">
                  <div className="text-[11px] text-indigo-700 font-semibold uppercase">Percentage</div>
                  <div className="text-2xl font-bold font-mono text-indigo-950 truncate">
                    {res ? `${formatNumber(res.result, 2)}%` : '—'}
                  </div>
                </div>
              </div>
            </div>

            {res && (
              <div className="space-y-4 pt-4 border-t border-slate-100">
                {/* Visual Ratio Bar */}
                <div>
                  <div className="flex justify-between text-xs text-slate-500 mb-1 font-mono">
                    <span>Part ({x2})</span>
                    <span>{formatNumber(res.result, 1)}%</span>
                  </div>
                  <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-indigo-600 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(Math.max(res.result, 0), 100)}%` }}
                    />
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                  <div className="font-mono text-slate-500">
                    Formula: {res.formula}
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleCopy(res.summary)}
                      className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-medium rounded transition-colors flex items-center gap-1"
                    >
                      {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>Copy</span>
                    </button>
                    <button
                      onClick={() => handleSaveHistory(res.summary, res.formula)}
                      className="px-2.5 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded transition-colors flex items-center gap-1"
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                      <span>Save</span>
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* Mode 3: Percentage Change */}
      {mode === 'percent-change' && (() => {
        const res = calc3();
        return (
          <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Initial Value (From)
                </label>
                <input
                  type="number"
                  step="any"
                  value={from3}
                  onChange={(e) => setFrom3(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Final Value (To)
                </label>
                <input
                  type="number"
                  step="any"
                  value={to3}
                  onChange={(e) => setTo3(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>
            </div>

            {res && (
              <div className="p-5 rounded-lg border border-slate-200/80 bg-slate-50/70 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold uppercase text-slate-500">
                    {res.isIncrease ? 'Percentage Increase' : 'Percentage Decrease'}
                  </span>
                  <span className="text-xs font-mono text-slate-500">
                    Absolute Difference: {formatNumber(res.diff)}
                  </span>
                </div>
                <div
                  className={`text-3xl font-extrabold font-mono tabular-nums ${
                    res.isIncrease ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {res.isIncrease ? '+' : ''}
                  {formatNumber(res.pct, 2)}%
                </div>
                <div className="text-xs text-slate-500 font-mono pt-1">
                  Formula: {res.formula}
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={() => handleCopy(res.summary)}
                    className="px-2.5 py-1.5 bg-white border border-slate-200 text-slate-700 text-xs font-medium rounded hover:bg-slate-50"
                  >
                    Copy
                  </button>
                  <button
                    onClick={() => handleSaveHistory(res.summary, res.formula)}
                    className="px-2.5 py-1.5 bg-indigo-600 text-white text-xs font-medium rounded hover:bg-indigo-700"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* Mode 4: Value Before % Change */}
      {mode === 'original-value' && (() => {
        const res = calc4();
        return (
          <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Final Value
                </label>
                <input
                  type="number"
                  step="any"
                  value={finalVal4}
                  onChange={(e) => setFinalVal4(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Change Type
                </label>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setType4('increase')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                      type4 === 'increase' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    Increase (+)
                  </button>
                  <button
                    type="button"
                    onClick={() => setType4('decrease')}
                    className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                      type4 === 'decrease' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    Decrease (-)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Percentage Applied (%)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    step="any"
                    value={rate4}
                    onChange={(e) => setRate4(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                  />
                  <span className="absolute right-3 top-2.5 text-slate-400 font-mono text-sm">%</span>
                </div>
              </div>
            </div>

            {res && (
              <div className="p-5 rounded-lg border border-slate-200/80 bg-slate-50/70 space-y-2">
                <div className="text-xs font-semibold uppercase text-slate-500">
                  Calculated Starting (Original) Value
                </div>
                <div className="text-3xl font-extrabold font-mono tabular-nums text-indigo-700">
                  {formatNumber(res.original, 2)}
                </div>
                <div className="text-xs text-slate-500 font-mono">
                  Formula: {res.formula}
                </div>
                <div className="flex justify-end gap-2 pt-2">
                  <button
                    onClick={() => handleCopy(res.summary)}
                    className="px-2.5 py-1.5 bg-white border border-slate-200 text-slate-700 text-xs font-medium rounded hover:bg-slate-50"
                  >
                    Copy
                  </button>
                  <button
                    onClick={() => handleSaveHistory(res.summary, res.formula)}
                    className="px-2.5 py-1.5 bg-indigo-600 text-white text-xs font-medium rounded hover:bg-indigo-700"
                  >
                    Save
                  </button>
                </div>
              </div>
            )}
          </div>
        );
      })()}

      {/* Mode 5: Margin & Markup */}
      {mode === 'margin-markup' && (() => {
        const res = calc5();
        return (
          <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Cost Price ($)
                </label>
                <input
                  type="number"
                  step="any"
                  value={cost5}
                  onChange={(e) => setCost5(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1.5">
                  Selling Price ($)
                </label>
                <input
                  type="number"
                  step="any"
                  value={sell5}
                  onChange={(e) => setSell5(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
              </div>
            </div>

            {res && (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-center">
                  <div className="text-xs font-medium text-slate-500">Gross Profit</div>
                  <div
                    className={`text-xl font-bold font-mono mt-1 ${
                      res.profit >= 0 ? 'text-emerald-600' : 'text-rose-600'
                    }`}
                  >
                    {formatNumber(res.profit, 2)}
                  </div>
                </div>

                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-center">
                  <div className="text-xs font-medium text-slate-500">Profit Margin</div>
                  <div className="text-xl font-bold font-mono text-indigo-700 mt-1">
                    {formatNumber(res.margin, 2)}%
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">(Profit / Revenue)</div>
                </div>

                <div className="p-4 bg-slate-50 rounded-lg border border-slate-200 text-center">
                  <div className="text-xs font-medium text-slate-500">Markup</div>
                  <div className="text-xl font-bold font-mono text-indigo-700 mt-1">
                    {formatNumber(res.markup, 2)}%
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">(Profit / Cost)</div>
                </div>
              </div>
            )}
          </div>
        );
      })()}
    </div>
  );
};
