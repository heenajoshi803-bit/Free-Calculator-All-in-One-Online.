import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Receipt, Copy, Bookmark, Check, Printer } from 'lucide-react';
import { formatCurrency, formatNumber, copyToClipboard } from '../../utils/formatters';

const GST_SLABS = [0, 5, 12, 18, 28];

export const GstCalculator: React.FC = () => {
  const { currency, addHistory, showToast } = useCalc();

  // Mode: exclusive (add GST) vs inclusive (remove GST from MRP)
  const [calculationType, setCalculationType] = useState<'exclusive' | 'inclusive'>('exclusive');
  const [amount, setAmount] = useState<string>('5000');
  const [gstRate, setGstRate] = useState<string>('18');
  const [taxSplit, setTaxSplit] = useState<'intra' | 'inter'>('intra'); // intra = CGST+SGST, inter = IGST

  const [copied, setCopied] = useState(false);

  const results = useMemo(() => {
    const inputVal = parseFloat(amount) || 0;
    const rate = parseFloat(gstRate) || 0;

    let baseAmount = 0;
    let gstAmount = 0;
    let totalAmount = 0;

    if (calculationType === 'exclusive') {
      // Add GST: input is net base amount
      baseAmount = inputVal;
      gstAmount = (baseAmount * rate) / 100;
      totalAmount = baseAmount + gstAmount;
    } else {
      // Inclusive GST: input is total price containing GST
      // Formula: Base = Total / (1 + Rate / 100)
      totalAmount = inputVal;
      baseAmount = totalAmount / (1 + rate / 100);
      gstAmount = totalAmount - baseAmount;
    }

    const cgstAmount = gstAmount / 2;
    const sgstAmount = gstAmount / 2;
    const igstAmount = gstAmount;

    return {
      inputVal,
      rate,
      baseAmount,
      gstAmount,
      totalAmount,
      cgstAmount,
      sgstAmount,
      igstAmount,
    };
  }, [calculationType, amount, gstRate]);

  const handleCopyInvoice = async () => {
    const taxLabel = taxSplit === 'intra'
      ? `CGST (${results.rate / 2}%): ${formatCurrency(results.cgstAmount, currency)}\nSGST (${results.rate / 2}%): ${formatCurrency(results.sgstAmount, currency)}`
      : `IGST (${results.rate}%): ${formatCurrency(results.igstAmount, currency)}`;

    const text = `--- GST TAX INVOICE BREAKDOWN ---\n` +
      `Mode: ${calculationType === 'exclusive' ? 'Exclusive (Added GST)' : 'Inclusive (Extracted GST)'}\n` +
      `Net Base Price: ${formatCurrency(results.baseAmount, currency)}\n` +
      `${taxLabel}\n` +
      `Total GST: ${formatCurrency(results.gstAmount, currency)} (${results.rate}%)\n` +
      `Total Gross Amount: ${formatCurrency(results.totalAmount, currency)}`;

    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Tax invoice breakdown copied');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveHistory = () => {
    addHistory({
      calculatorId: 'gst',
      calculatorName: 'GST Calculator',
      summary: `Total: ${formatCurrency(results.totalAmount, currency)} (GST: ${formatCurrency(results.gstAmount, currency)} @ ${results.rate}%)`,
      details: `Base: ${formatCurrency(results.baseAmount, currency)} · ${calculationType === 'exclusive' ? 'Exclusive' : 'Inclusive'} · Split: ${taxSplit === 'intra' ? 'CGST+SGST' : 'IGST'}`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">GST Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Goods & Services Tax</span>
          <span aria-hidden="true">·</span>
          <span>Exclusive & Inclusive Tax</span>
          <span aria-hidden="true">·</span>
          <span>CGST / SGST / IGST Split</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
          {/* Mode Switcher */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              GST Calculation Type
            </label>
            <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setCalculationType('exclusive')}
                className={`py-2 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  calculationType === 'exclusive'
                    ? 'bg-white text-indigo-700 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Exclusive GST (+ Add Tax)
              </button>
              <button
                type="button"
                onClick={() => setCalculationType('inclusive')}
                className={`py-2 text-xs font-semibold rounded-md transition-all cursor-pointer ${
                  calculationType === 'inclusive'
                    ? 'bg-white text-indigo-700 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Inclusive GST (Extract Tax from MRP)
              </button>
            </div>
            <p className="text-[11px] text-slate-400 mt-1.5">
              {calculationType === 'exclusive'
                ? 'Adds GST onto the original manufacturing or service base price.'
                : 'Extracts the net base price and taxes from the final retail retail MRP price.'}
            </p>
          </div>

          {/* Amount Input */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              {calculationType === 'exclusive' ? 'Net Amount (Base Price)' : 'Total Amount (MRP with GST)'}
            </label>
            <div className="relative">
              <input
                type="number"
                step="any"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                className="w-full px-4 py-2.5 text-base font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
            </div>
          </div>

          {/* Standard GST Slabs & Custom Rate */}
          <div>
            <div className="flex items-center justify-between mb-2">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                GST Tax Slab (%)
              </label>
              <span className="text-xs font-mono font-medium text-indigo-600">{gstRate}%</span>
            </div>

            <div className="grid grid-cols-5 gap-2 mb-2.5">
              {GST_SLABS.map((slab) => (
                <button
                  key={slab}
                  type="button"
                  onClick={() => setGstRate(slab.toString())}
                  className={`py-2 text-xs font-bold rounded-lg border transition-all ${
                    gstRate === slab.toString()
                      ? 'bg-indigo-600 text-white border-indigo-600 shadow-xs'
                      : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                  }`}
                >
                  {slab}%
                </button>
              ))}
            </div>

            {/* Custom Rate input */}
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Or custom rate:</span>
              <div className="relative w-28">
                <input
                  type="number"
                  step="any"
                  value={gstRate}
                  onChange={(e) => setGstRate(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                />
                <span className="absolute right-2.5 top-1.5 text-slate-400 font-mono text-xs">%</span>
              </div>
            </div>
          </div>

          {/* Tax Division Toggle: Intra-State vs Inter-State */}
          <div className="pt-2 border-t border-slate-100">
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-2">
              Tax Supply Type
            </label>
            <div className="grid grid-cols-2 gap-2">
              <label
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-all flex items-start gap-2.5 ${
                  taxSplit === 'intra'
                    ? 'border-indigo-600 bg-indigo-50/40 text-slate-900'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="taxSplit"
                  checked={taxSplit === 'intra'}
                  onChange={() => setTaxSplit('intra')}
                  className="mt-0.5 text-indigo-600"
                />
                <div>
                  <div className="font-semibold">Intra-State Supply</div>
                  <div className="text-[11px] text-slate-500">CGST (50%) + SGST (50%)</div>
                </div>
              </label>

              <label
                className={`p-3 rounded-lg border text-xs cursor-pointer transition-all flex items-start gap-2.5 ${
                  taxSplit === 'inter'
                    ? 'border-indigo-600 bg-indigo-50/40 text-slate-900'
                    : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                }`}
              >
                <input
                  type="radio"
                  name="taxSplit"
                  checked={taxSplit === 'inter'}
                  onChange={() => setTaxSplit('inter')}
                  className="mt-0.5 text-indigo-600"
                />
                <div>
                  <div className="font-semibold">Inter-State Supply</div>
                  <div className="text-[11px] text-slate-500">IGST (100% Integrated)</div>
                </div>
              </label>
            </div>
          </div>
        </div>

        {/* Right Invoice Receipt Panel */}
        <div className="lg:col-span-5 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-xs overflow-hidden">
            {/* Receipt Header */}
            <div className="bg-slate-900 text-white p-5">
              <div className="flex items-center justify-between">
                <div className="text-xs font-semibold tracking-wider uppercase text-slate-400">
                  Tax Breakdown
                </div>
                <Receipt className="w-4 h-4 text-indigo-400" />
              </div>
              <div className="text-2xl sm:text-3xl font-bold font-mono tabular-nums mt-2">
                {formatCurrency(results.totalAmount, currency)}
              </div>
              <div className="text-xs text-slate-400 mt-1">
                Total Billing Amount ({calculationType === 'exclusive' ? 'Base + GST' : 'Inclusive MRP'})
              </div>
            </div>

            {/* Receipt Body */}
            <div className="p-5 space-y-3.5 text-xs">
              <div className="flex justify-between py-1 border-b border-slate-100">
                <span className="text-slate-500">Net Base Price:</span>
                <span className="font-semibold font-mono text-slate-800">
                  {formatCurrency(results.baseAmount, currency)}
                </span>
              </div>

              {taxSplit === 'intra' ? (
                <>
                  <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                    <span>CGST ({results.rate / 2}%):</span>
                    <span className="font-mono">{formatCurrency(results.cgstAmount, currency)}</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                    <span>SGST ({results.rate / 2}%):</span>
                    <span className="font-mono">{formatCurrency(results.sgstAmount, currency)}</span>
                  </div>
                </>
              ) : (
                <div className="flex justify-between py-1 border-b border-slate-100 text-slate-600">
                  <span>IGST ({results.rate}%):</span>
                  <span className="font-mono">{formatCurrency(results.igstAmount, currency)}</span>
                </div>
              )}

              <div className="flex justify-between py-1 border-b border-slate-100 font-semibold text-indigo-700">
                <span>Total GST Amount:</span>
                <span className="font-mono">{formatCurrency(results.gstAmount, currency)}</span>
              </div>

              <div className="flex justify-between pt-1 text-sm font-bold text-slate-900">
                <span>Gross Payable:</span>
                <span className="font-mono">{formatCurrency(results.totalAmount, currency)}</span>
              </div>

              {/* Action Buttons */}
              <div className="pt-4 flex items-center gap-2">
                <button
                  onClick={handleCopyInvoice}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Invoice'}</span>
                </button>
                <button
                  onClick={handleSaveHistory}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  <span>Save</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
