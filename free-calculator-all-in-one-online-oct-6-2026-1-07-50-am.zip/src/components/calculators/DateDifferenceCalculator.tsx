import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Calendar, Copy, Bookmark, Check, Plus, Minus, ArrowRight } from 'lucide-react';
import { copyToClipboard } from '../../utils/formatters';

export const DateDifferenceCalculator: React.FC = () => {
  const { addHistory, showToast } = useCalc();
  const [mode, setMode] = useState<'difference' | 'add-subtract'>('difference');

  const todayStr = useMemo(() => new Date().toISOString().split('T')[0], []);
  const defaultEndStr = useMemo(() => {
    const d = new Date();
    d.setDate(d.getDate() + 90);
    return d.toISOString().split('T')[0];
  }, []);

  // Difference inputs
  const [startDate, setStartDate] = useState<string>(todayStr);
  const [endDate, setEndDate] = useState<string>(defaultEndStr);
  const [includeEndDay, setIncludeEndDay] = useState<boolean>(true);

  // Add/Subtract inputs
  const [baseDate, setBaseDate] = useState<string>(todayStr);
  const [operation, setOperation] = useState<'add' | 'subtract'>('add');
  const [addYears, setAddYears] = useState<string>('0');
  const [addMonths, setAddMonths] = useState<string>('0');
  const [addWeeks, setAddWeeks] = useState<string>('0');
  const [addDays, setAddDays] = useState<string>('30');
  const [isBusinessDaysOnly, setIsBusinessDaysOnly] = useState<boolean>(false);

  const [copied, setCopied] = useState(false);

  // Difference Calculation
  const diffResults = useMemo(() => {
    if (!startDate || !endDate) return null;
    const start = new Date(startDate + 'T00:00:00');
    const end = new Date(endDate + 'T00:00:00');

    if (isNaN(start.getTime()) || isNaN(end.getTime())) return null;

    const isReversed = start > end;
    const [early, late] = isReversed ? [end, start] : [start, end];

    // Calendar day diff
    let totalDays = Math.round((late.getTime() - early.getTime()) / (1000 * 60 * 60 * 24));
    if (includeEndDay) totalDays += 1;

    // Count business days (Mon-Fri) & weekend days (Sat-Sun)
    let businessDays = 0;
    let weekendDays = 0;
    const current = new Date(early.getTime());
    const stopLimit = new Date(late.getTime());
    if (!includeEndDay) {
      stopLimit.setDate(stopLimit.getDate() - 1);
    }

    while (current <= stopLimit) {
      const dayOfWeek = current.getDay(); // 0 is Sunday, 6 is Saturday
      if (dayOfWeek === 0 || dayOfWeek === 6) {
        weekendDays++;
      } else {
        businessDays++;
      }
      current.setDate(current.getDate() + 1);
    }

    // Breakdown into Years, Months, Days
    let y = late.getFullYear() - early.getFullYear();
    let m = late.getMonth() - early.getMonth();
    let d = late.getDate() - early.getDate();

    if (includeEndDay) {
      d += 1;
    }

    if (d < 0) {
      m -= 1;
      const prevMonth = new Date(late.getFullYear(), late.getMonth(), 0);
      d += prevMonth.getDate();
    }
    if (m < 0) {
      y -= 1;
      m += 12;
    }

    const weeks = Math.floor(totalDays / 7);
    const remainingDaysAfterWeeks = totalDays % 7;
    const totalHours = totalDays * 24;
    const totalMinutes = totalHours * 60;

    return {
      totalDays,
      businessDays,
      weekendDays,
      y,
      m,
      d,
      weeks,
      remainingDaysAfterWeeks,
      totalHours,
      totalMinutes,
      isReversed,
    };
  }, [startDate, endDate, includeEndDay]);

  // Add / Subtract Calculation
  const addSubResults = useMemo(() => {
    if (!baseDate) return null;
    const start = new Date(baseDate + 'T00:00:00');
    if (isNaN(start.getTime())) return null;

    const y = parseInt(addYears) || 0;
    const m = parseInt(addMonths) || 0;
    const w = parseInt(addWeeks) || 0;
    const d = parseInt(addDays) || 0;

    const target = new Date(start.getTime());
    const mult = operation === 'add' ? 1 : -1;

    if (isBusinessDaysOnly) {
      // Step business days only
      let remainingBizDays = d;
      while (remainingBizDays > 0) {
        target.setDate(target.getDate() + mult);
        const dayOfWeek = target.getDay();
        if (dayOfWeek !== 0 && dayOfWeek !== 6) {
          remainingBizDays--;
        }
      }
    } else {
      if (y !== 0) target.setFullYear(target.getFullYear() + mult * y);
      if (m !== 0) target.setMonth(target.getMonth() + mult * m);
      const totalExtraDays = (w * 7 + d) * mult;
      target.setDate(target.getDate() + totalExtraDays);
    }

    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const dayName = daysOfWeek[target.getDay()];

    const formattedTarget = target.toLocaleDateString(undefined, {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });

    const diffFromToday = Math.round((target.getTime() - new Date().setHours(0, 0, 0, 0)) / (1000 * 60 * 60 * 24));

    return {
      targetDateStr: target.toISOString().split('T')[0],
      dayName,
      formattedTarget,
      diffFromToday,
    };
  }, [baseDate, operation, addYears, addMonths, addWeeks, addDays, isBusinessDaysOnly]);

  const handleCopy = async (text: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Date report copied');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveDiffHistory = () => {
    if (!diffResults) return;
    addHistory({
      calculatorId: 'date-diff',
      calculatorName: 'Date Difference Calculator',
      summary: `${diffResults.totalDays} Total Days (${diffResults.businessDays} Working Days)`,
      details: `${startDate} to ${endDate} · ${diffResults.y}y ${diffResults.m}m ${diffResults.d}d · ${diffResults.weekendDays} Weekend Days`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Date Difference Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Calendar & Working Days</span>
          <span aria-hidden="true">·</span>
          <span>Weekend Exclusion</span>
          <span aria-hidden="true">·</span>
          <span>Add / Subtract Date Calculator</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl w-fit">
        <button
          onClick={() => setMode('difference')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            mode === 'difference' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
          }`}
        >
          Difference Between 2 Dates
        </button>
        <button
          onClick={() => setMode('add-subtract')}
          className={`px-3.5 py-1.5 text-xs font-semibold rounded-lg transition-colors cursor-pointer ${
            mode === 'add-subtract' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
          }`}
        >
          Add / Subtract from a Date
        </button>
      </div>

      {mode === 'difference' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Form */}
          <div className="lg:col-span-6 bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Start Date
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
              <button
                type="button"
                onClick={() => setStartDate(todayStr)}
                className="text-[11px] text-indigo-600 hover:underline mt-1"
              >
                Set to Today
              </button>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                End Date
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
              />
            </div>

            {/* Quick date presets */}
            <div className="flex items-center gap-1.5 flex-wrap pt-1">
              <span className="text-[11px] text-slate-400">Quick End:</span>
              {[
                { label: '+30 Days', days: 30 },
                { label: '+90 Days', days: 90 },
                { label: '+180 Days', days: 180 },
                { label: '+1 Year', days: 365 },
              ].map((p) => (
                <button
                  key={p.label}
                  type="button"
                  onClick={() => {
                    const d = new Date(startDate || todayStr);
                    d.setDate(d.getDate() + p.days);
                    setEndDate(d.toISOString().split('T')[0]);
                  }}
                  className="px-2 py-0.5 text-xs text-slate-600 bg-slate-100 hover:bg-slate-200 rounded text-[11px] font-mono transition-colors"
                >
                  {p.label}
                </button>
              ))}
            </div>

            {/* Toggles */}
            <div className="pt-2 border-t border-slate-100 space-y-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-medium text-slate-700">
                <input
                  type="checkbox"
                  checked={includeEndDay}
                  onChange={(e) => setIncludeEndDay(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                />
                <span>Include End Date in calculation (+1 day)</span>
              </label>
            </div>
          </div>

          {/* Right Output */}
          <div className="lg:col-span-6 space-y-4">
            {diffResults && (
              <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-5">
                <div>
                  <div className="text-xs font-semibold uppercase tracking-wider text-indigo-600 mb-1">
                    Total Duration
                  </div>
                  <div className="text-3xl sm:text-4xl font-extrabold font-mono tabular-nums text-slate-900">
                    {diffResults.totalDays}{' '}
                    <span className="text-base text-slate-500 font-medium">calendar days</span>
                  </div>
                  <div className="text-xs text-slate-500 mt-1">
                    {diffResults.y} years, {diffResults.m} months, {diffResults.d} days
                  </div>
                </div>

                {/* Business vs Weekend days cards */}
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="p-3.5 bg-emerald-50/70 border border-emerald-200/80 rounded-lg">
                    <div className="text-emerald-800 font-medium">Working / Business Days</div>
                    <div className="text-2xl font-bold font-mono text-emerald-700 mt-1">
                      {diffResults.businessDays}
                    </div>
                    <div className="text-[10px] text-emerald-600 mt-0.5">Excludes Sat &amp; Sun</div>
                  </div>

                  <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-lg">
                    <div className="text-slate-500 font-medium">Weekend Days</div>
                    <div className="text-2xl font-bold font-mono text-slate-800 mt-1">
                      {diffResults.weekendDays}
                    </div>
                    <div className="text-[10px] text-slate-400 mt-0.5">Saturday + Sunday</div>
                  </div>
                </div>

                {/* Additional Units */}
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/60">
                    <div className="text-slate-400 text-[10px]">Weeks</div>
                    <div className="font-bold font-mono text-slate-800 mt-0.5">
                      {diffResults.weeks}w {diffResults.remainingDaysAfterWeeks}d
                    </div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/60">
                    <div className="text-slate-400 text-[10px]">Total Hours</div>
                    <div className="font-bold font-mono text-slate-800 mt-0.5">
                      {diffResults.totalHours.toLocaleString()}
                    </div>
                  </div>
                  <div className="p-2.5 bg-slate-50 rounded-lg border border-slate-200/60">
                    <div className="text-slate-400 text-[10px]">Total Minutes</div>
                    <div className="font-bold font-mono text-slate-800 mt-0.5">
                      {diffResults.totalMinutes.toLocaleString()}
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-2 flex items-center gap-2">
                  <button
                    onClick={() =>
                      handleCopy(
                        `Duration: ${diffResults.totalDays} calendar days\n` +
                        `Working Days: ${diffResults.businessDays} business days\n` +
                        `Weekend Days: ${diffResults.weekendDays}\n` +
                        `Breakdown: ${diffResults.y}y, ${diffResults.m}m, ${diffResults.d}d`
                      )
                    }
                    className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center gap-1.5"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied' : 'Copy'}</span>
                  </button>
                  <button
                    onClick={handleSaveDiffHistory}
                    className="flex-1 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center justify-center gap-1.5"
                  >
                    <Bookmark className="w-3.5 h-3.5" />
                    <span>Save</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      ) : (
        /* Add / Subtract Date View */
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
          <div className="max-w-2xl space-y-5">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Start From Date
                </label>
                <input
                  type="date"
                  value={baseDate}
                  onChange={(e) => setBaseDate(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Operation
                </label>
                <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
                  <button
                    type="button"
                    onClick={() => setOperation('add')}
                    className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1 ${
                      operation === 'add' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    <Plus className="w-3.5 h-3.5" /> Add
                  </button>
                  <button
                    type="button"
                    onClick={() => setOperation('subtract')}
                    className={`flex-1 py-2 text-xs font-semibold rounded-md transition-colors flex items-center justify-center gap-1 ${
                      operation === 'subtract' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    <Minus className="w-3.5 h-3.5" /> Subtract
                  </button>
                </div>
              </div>
            </div>

            {/* Inputs: Years, Months, Weeks, Days */}
            {!isBusinessDaysOnly ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Years</label>
                  <input
                    type="number"
                    min="0"
                    value={addYears}
                    onChange={(e) => setAddYears(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono font-semibold bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Months</label>
                  <input
                    type="number"
                    min="0"
                    value={addMonths}
                    onChange={(e) => setAddMonths(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono font-semibold bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Weeks</label>
                  <input
                    type="number"
                    min="0"
                    value={addWeeks}
                    onChange={(e) => setAddWeeks(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono font-semibold bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-600 mb-1">Days</label>
                  <input
                    type="number"
                    min="0"
                    value={addDays}
                    onChange={(e) => setAddDays(e.target.value)}
                    className="w-full px-3 py-2 text-sm font-mono font-semibold bg-slate-50 border border-slate-300 rounded-lg"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">
                  Business Days to {operation === 'add' ? 'Add' : 'Subtract'}
                </label>
                <input
                  type="number"
                  min="1"
                  value={addDays}
                  onChange={(e) => setAddDays(e.target.value)}
                  className="w-48 px-3 py-2 text-sm font-mono font-semibold bg-slate-50 border border-slate-300 rounded-lg"
                />
                <span className="text-xs text-slate-400 ml-2">Skips weekends automatically</span>
              </div>
            )}

            <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
              <input
                type="checkbox"
                checked={isBusinessDaysOnly}
                onChange={(e) => setIsBusinessDaysOnly(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded border-slate-300"
              />
              <span>Count Business Days only (Monday to Friday)</span>
            </label>

            {/* Target Date Result */}
            {addSubResults && (
              <div className="p-5 bg-indigo-50/70 border border-indigo-100 rounded-xl space-y-2">
                <div className="text-xs font-semibold text-indigo-700 uppercase tracking-wider">
                  Resulting Date
                </div>
                <div className="text-2xl sm:text-3xl font-bold text-slate-900">
                  {addSubResults.formattedTarget}
                </div>
                <div className="text-xs text-slate-500 font-mono">
                  {addSubResults.diffFromToday === 0
                    ? 'Today'
                    : addSubResults.diffFromToday > 0
                    ? `${addSubResults.diffFromToday} days from today`
                    : `${Math.abs(addSubResults.diffFromToday)} days in the past`}
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
