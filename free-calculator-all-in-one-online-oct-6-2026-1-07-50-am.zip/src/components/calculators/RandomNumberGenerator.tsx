import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Dices, Copy, Bookmark, Check, Shuffle, RotateCcw, KeyRound, Award } from 'lucide-react';
import { copyToClipboard, formatNumber } from '../../utils/formatters';

type Tab = 'numbers' | 'dice' | 'coin' | 'picker' | 'password';

export const RandomNumberGenerator: React.FC = () => {
  const { addHistory, showToast } = useCalc();
  const [activeTab, setActiveTab] = useState<Tab>('numbers');

  // Mode 1: Numbers
  const [minVal, setMinVal] = useState<number>(1);
  const [maxVal, setMaxVal] = useState<number>(100);
  const [count, setCount] = useState<number>(5);
  const [allowDuplicates, setAllowDuplicates] = useState<boolean>(false);
  const [sortOrder, setSortOrder] = useState<'none' | 'asc' | 'desc'>('none');
  const [generatedNumbers, setGeneratedNumbers] = useState<number[]>([14, 27, 42, 68, 93]);

  // Mode 2: Dice
  const [diceSides, setDiceSides] = useState<number>(6); // d4, d6, d8, d10, d12, d20, d100
  const [diceCount, setDiceCount] = useState<number>(2);
  const [diceModifier, setDiceModifier] = useState<number>(0);
  const [rolledDice, setRolledDice] = useState<number[]>([4, 6]);

  // Mode 3: Coin Flip
  const [coinCount, setCoinCount] = useState<number>(3);
  const [coinResults, setCoinResults] = useState<('Heads' | 'Tails')[]>(['Heads', 'Tails', 'Heads']);

  // Mode 4: List Picker
  const [listText, setListText] = useState<string>('Alice\nBob\nCharlie\nDiana\nEvan\nFiona');
  const [pickedItems, setPickedItems] = useState<string[]>(['Charlie']);

  // Mode 5: Password / PIN
  const [passLength, setPassLength] = useState<number>(16);
  const [includeUpper, setIncludeUpper] = useState<boolean>(true);
  const [includeLower, setIncludeLower] = useState<boolean>(true);
  const [includeNumbers, setIncludeNumbers] = useState<boolean>(true);
  const [includeSymbols, setIncludeSymbols] = useState<boolean>(true);
  const [generatedPassword, setGeneratedPassword] = useState<string>('mK9#vP2$xL7@wQ5!');

  const [copied, setCopied] = useState<boolean>(false);

  // Generate Random Numbers
  const handleGenerateNumbers = () => {
    const min = Math.min(minVal, maxVal);
    const max = Math.max(minVal, maxVal);
    const totalRange = max - min + 1;
    const requestedCount = Math.min(Math.max(1, count), 500);

    let result: number[] = [];

    if (!allowDuplicates && requestedCount > totalRange) {
      showToast(`Cannot generate ${requestedCount} unique numbers from range of ${totalRange}`);
      return;
    }

    if (!allowDuplicates) {
      const set = new Set<number>();
      while (set.size < requestedCount) {
        const rand = Math.floor(Math.random() * totalRange) + min;
        set.add(rand);
      }
      result = Array.from(set);
    } else {
      for (let i = 0; i < requestedCount; i++) {
        result.push(Math.floor(Math.random() * totalRange) + min);
      }
    }

    if (sortOrder === 'asc') result.sort((a, b) => a - b);
    if (sortOrder === 'desc') result.sort((a, b) => b - a);

    setGeneratedNumbers(result);
  };

  // Roll Dice
  const handleRollDice = () => {
    const rolls: number[] = [];
    for (let i = 0; i < diceCount; i++) {
      rolls.push(Math.floor(Math.random() * diceSides) + 1);
    }
    setRolledDice(rolls);
  };

  // Flip Coins
  const handleFlipCoins = () => {
    const flips: ('Heads' | 'Tails')[] = [];
    for (let i = 0; i < coinCount; i++) {
      flips.push(Math.random() > 0.5 ? 'Heads' : 'Tails');
    }
    setCoinResults(flips);
  };

  // Pick from List
  const handlePickWinner = () => {
    const items = listText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
    if (items.length === 0) return;
    const randomIndex = Math.floor(Math.random() * items.length);
    setPickedItems([items[randomIndex]]);
  };

  const handleShuffleList = () => {
    const items = listText
      .split('\n')
      .map((s) => s.trim())
      .filter(Boolean);
    for (let i = items.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [items[i], items[j]] = [items[j], items[i]];
    }
    setListText(items.join('\n'));
    showToast('List shuffled');
  };

  // Generate Password
  const handleGeneratePassword = () => {
    let chars = '';
    if (includeUpper) chars += 'ABCDEFGHJKLMNPQRSTUVWXYZ';
    if (includeLower) chars += 'abcdefghijkmnopqrstuvwxyz';
    if (includeNumbers) chars += '23456789';
    if (includeSymbols) chars += '!@#$%^&*()-_=+[]{}|;:,.<>?';

    if (!chars) chars = 'abcdefghijkmnopqrstuvwxyz';

    let pass = '';
    for (let i = 0; i < passLength; i++) {
      pass += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setGeneratedPassword(pass);
  };

  const handleCopy = async (text: string) => {
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('Copied to clipboard');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  // Number stats
  const numberStats = useMemo(() => {
    if (generatedNumbers.length === 0) return null;
    const sum = generatedNumbers.reduce((a, b) => a + b, 0);
    const avg = sum / generatedNumbers.length;
    const min = Math.min(...generatedNumbers);
    const max = Math.max(...generatedNumbers);
    return { sum, avg, min, max };
  }, [generatedNumbers]);

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">Random Generator Suite</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>Random Numbers</span>
          <span aria-hidden="true">·</span>
          <span>Virtual Polyhedral Dice</span>
          <span aria-hidden="true">·</span>
          <span>Coin Flipper</span>
          <span aria-hidden="true">·</span>
          <span>List Picker &amp; PIN/Password</span>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl overflow-x-auto">
        {[
          { id: 'numbers', label: 'Random Numbers' },
          { id: 'dice', label: 'Polyhedral Dice' },
          { id: 'coin', label: 'Coin Flipper' },
          { id: 'picker', label: 'List Picker' },
          { id: 'password', label: 'PIN / Password' },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as Tab)}
            className={`px-3.5 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
              activeTab === tab.id ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab 1: Random Numbers */}
      {activeTab === 'numbers' && (
        <div className="space-y-5">
          <div className="bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-4">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Min Value</label>
                <input
                  type="number"
                  value={minVal}
                  onChange={(e) => setMinVal(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Max Value</label>
                <input
                  type="number"
                  value={maxVal}
                  onChange={(e) => setMaxVal(parseInt(e.target.value) || 0)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Quantity</label>
                <input
                  type="number"
                  min="1"
                  max="500"
                  value={count}
                  onChange={(e) => setCount(parseInt(e.target.value) || 1)}
                  className="w-full px-3 py-2 text-sm font-semibold font-mono bg-slate-50 border border-slate-300 rounded-lg"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-600 mb-1">Sorting</label>
                <select
                  value={sortOrder}
                  onChange={(e) => setSortOrder(e.target.value as any)}
                  className="w-full px-3 py-2 text-xs font-medium bg-slate-50 border border-slate-300 rounded-lg"
                >
                  <option value="none">As Drawn (None)</option>
                  <option value="asc">Ascending (Low to High)</option>
                  <option value="desc">Descending (High to Low)</option>
                </select>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <label className="flex items-center gap-2 cursor-pointer text-xs text-slate-700">
                <input
                  type="checkbox"
                  checked={allowDuplicates}
                  onChange={(e) => setAllowDuplicates(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 rounded border-slate-300"
                />
                <span>Allow duplicate numbers</span>
              </label>

              <button
                onClick={handleGenerateNumbers}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-2xs flex items-center gap-2 transition-colors cursor-pointer"
              >
                <Shuffle className="w-4 h-4" />
                <span>Generate Numbers</span>
              </button>
            </div>
          </div>

          {/* Results Grid */}
          <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Generated {generatedNumbers.length} Number{generatedNumbers.length > 1 ? 's' : ''}
              </div>
              <button
                onClick={() => handleCopy(generatedNumbers.join(', '))}
                className="px-3 py-1.5 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-md flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy All</span>
              </button>
            </div>

            <div className="flex flex-wrap gap-2.5 max-h-72 overflow-y-auto p-2 bg-slate-50 rounded-lg border border-slate-200/70">
              {generatedNumbers.map((num, idx) => (
                <span
                  key={idx}
                  className="px-3.5 py-2 bg-white border border-slate-200 text-slate-900 font-mono text-base font-bold rounded-lg shadow-2xs select-all"
                >
                  {num}
                </span>
              ))}
            </div>

            {numberStats && (
              <div className="grid grid-cols-4 gap-3 text-center text-xs pt-2 border-t border-slate-100">
                <div className="p-2 bg-slate-50 rounded">
                  <div className="text-slate-400">Sum</div>
                  <div className="font-mono font-bold text-slate-800">{numberStats.sum.toLocaleString()}</div>
                </div>
                <div className="p-2 bg-slate-50 rounded">
                  <div className="text-slate-400">Average</div>
                  <div className="font-mono font-bold text-slate-800">{formatNumber(numberStats.avg, 2)}</div>
                </div>
                <div className="p-2 bg-slate-50 rounded">
                  <div className="text-slate-400">Min</div>
                  <div className="font-mono font-bold text-slate-800">{numberStats.min}</div>
                </div>
                <div className="p-2 bg-slate-50 rounded">
                  <div className="text-slate-400">Max</div>
                  <div className="font-mono font-bold text-slate-800">{numberStats.max}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 2: Dice Roller */}
      {activeTab === 'dice' && (
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
          <div className="flex items-center gap-2 overflow-x-auto pb-1">
            {[4, 6, 8, 10, 12, 20, 100].map((d) => (
              <button
                key={d}
                onClick={() => setDiceSides(d)}
                className={`px-3 py-1.5 text-xs font-bold rounded-lg border transition-all ${
                  diceSides === d
                    ? 'bg-indigo-600 text-white border-indigo-600'
                    : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                d{d}
              </button>
            ))}
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Number of Dice</label>
              <input
                type="number"
                min="1"
                max="20"
                value={diceCount}
                onChange={(e) => setDiceCount(parseInt(e.target.value) || 1)}
                className="w-24 px-3 py-2 text-sm font-semibold font-mono bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Modifier (+/-)</label>
              <input
                type="number"
                value={diceModifier}
                onChange={(e) => setDiceModifier(parseInt(e.target.value) || 0)}
                className="w-24 px-3 py-2 text-sm font-semibold font-mono bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>

            <div className="pt-5">
              <button
                onClick={handleRollDice}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-2xs flex items-center gap-2 cursor-pointer"
              >
                <Dices className="w-4 h-4" />
                <span>Roll {diceCount}d{diceSides}</span>
              </button>
            </div>
          </div>

          {/* Dice Results Display */}
          <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 text-center space-y-4">
            <div className="flex justify-center items-center gap-3 flex-wrap">
              {rolledDice.map((roll, idx) => (
                <div
                  key={idx}
                  className="w-14 h-14 bg-white border-2 border-slate-300 rounded-xl flex items-center justify-center font-mono text-2xl font-extrabold text-indigo-700 shadow-sm"
                >
                  {roll}
                </div>
              ))}
            </div>

            <div className="text-sm font-medium text-slate-600">
              Total Sum:{' '}
              <strong className="text-xl font-bold font-mono text-slate-900 ml-1">
                {rolledDice.reduce((a, b) => a + b, 0) + diceModifier}
              </strong>
              {diceModifier !== 0 && (
                <span className="text-xs text-slate-400 font-mono ml-1">
                  ({rolledDice.join(' + ')} {diceModifier >= 0 ? `+ ${diceModifier}` : `- ${Math.abs(diceModifier)}`})
                </span>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Coin Flipper */}
      {activeTab === 'coin' && (
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-6">
          <div className="flex items-center gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-600 mb-1">Number of Coins</label>
              <input
                type="number"
                min="1"
                max="10"
                value={coinCount}
                onChange={(e) => setCoinCount(parseInt(e.target.value) || 1)}
                className="w-24 px-3 py-2 text-sm font-semibold font-mono bg-slate-50 border border-slate-300 rounded-lg"
              />
            </div>
            <div className="pt-5">
              <button
                onClick={handleFlipCoins}
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg shadow-2xs flex items-center gap-2 cursor-pointer"
              >
                <span>Flip Coins</span>
              </button>
            </div>
          </div>

          <div className="p-8 bg-slate-50 rounded-xl border border-slate-200 flex justify-center items-center gap-4 flex-wrap">
            {coinResults.map((coin, idx) => (
              <div
                key={idx}
                className={`w-20 h-20 rounded-full border-4 flex flex-col items-center justify-center font-bold text-sm shadow-md transition-transform duration-200 ${
                  coin === 'Heads'
                    ? 'bg-amber-100 border-amber-400 text-amber-900'
                    : 'bg-slate-200 border-slate-400 text-slate-800'
                }`}
              >
                <span className="text-xs uppercase">{coin}</span>
              </div>
            ))}
          </div>

          <div className="text-xs text-center text-slate-500 font-mono">
            Heads: {coinResults.filter((c) => c === 'Heads').length} · Tails:{' '}
            {coinResults.filter((c) => c === 'Tails').length}
          </div>
        </div>
      )}

      {/* Tab 4: List Picker */}
      {activeTab === 'picker' && (
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-5">
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
              Items or Names (One per line)
            </label>
            <textarea
              rows={6}
              value={listText}
              onChange={(e) => setListText(e.target.value)}
              className="w-full p-3 font-mono text-sm bg-slate-50 border border-slate-300 rounded-lg"
            />
          </div>

          <div className="flex gap-2">
            <button
              onClick={handlePickWinner}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg flex items-center gap-2 cursor-pointer"
            >
              <Award className="w-4 h-4" />
              <span>Pick Random Winner</span>
            </button>
            <button
              onClick={handleShuffleList}
              className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
            >
              <Shuffle className="w-4 h-4" />
              <span>Shuffle Entire List</span>
            </button>
          </div>

          {pickedItems.length > 0 && (
            <div className="p-6 bg-indigo-50 border border-indigo-200 rounded-xl text-center space-y-1">
              <div className="text-xs font-semibold uppercase text-indigo-700 tracking-wider">
                Selected Winner
              </div>
              <div className="text-3xl font-extrabold text-slate-900 font-mono">
                {pickedItems[0]}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: Password / PIN */}
      {activeTab === 'password' && (
        <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-5">
          <div>
            <div className="flex justify-between items-center mb-1">
              <label className="text-xs font-semibold text-slate-700 uppercase tracking-wider">
                Length: {passLength} characters
              </label>
            </div>
            <input
              type="range"
              min="4"
              max="64"
              value={passLength}
              onChange={(e) => setPassLength(parseInt(e.target.value))}
              className="w-full h-2 bg-slate-200 rounded-lg cursor-pointer accent-indigo-600"
            />
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeUpper}
                onChange={(e) => setIncludeUpper(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
              <span>Uppercase (A-Z)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeLower}
                onChange={(e) => setIncludeLower(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
              <span>Lowercase (a-z)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeNumbers}
                onChange={(e) => setIncludeNumbers(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
              <span>Numbers (0-9)</span>
            </label>
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={includeSymbols}
                onChange={(e) => setIncludeSymbols(e.target.checked)}
                className="w-4 h-4 text-indigo-600 rounded"
              />
              <span>Symbols (!@#$)</span>
            </label>
          </div>

          <div className="pt-2">
            <button
              onClick={handleGeneratePassword}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-lg flex items-center gap-2 cursor-pointer"
            >
              <KeyRound className="w-4 h-4" />
              <span>Generate Secure Key</span>
            </button>
          </div>

          {generatedPassword && (
            <div className="p-4 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between gap-4">
              <span className="font-mono text-lg font-bold text-slate-900 tracking-wider truncate select-all">
                {generatedPassword}
              </span>
              <button
                onClick={() => handleCopy(generatedPassword)}
                className="px-3.5 py-1.5 text-xs font-semibold text-slate-700 bg-white border border-slate-200 hover:bg-slate-100 rounded-md shrink-0 flex items-center gap-1.5"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                <span>Copy</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
