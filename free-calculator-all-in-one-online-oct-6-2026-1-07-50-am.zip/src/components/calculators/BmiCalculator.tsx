import React, { useState, useMemo } from 'react';
import { useCalc } from '../../context/CalcContext';
import { Activity, Copy, Bookmark, Check, Heart, Flame } from 'lucide-react';
import { formatNumber, copyToClipboard } from '../../utils/formatters';

type UnitSystem = 'metric' | 'imperial';
type Gender = 'male' | 'female';

export const BmiCalculator: React.FC = () => {
  const { addHistory, showToast } = useCalc();
  const [unit, setUnit] = useState<UnitSystem>('metric');
  const [gender, setGender] = useState<Gender>('male');
  const [age, setAge] = useState<string>('28');

  // Metric inputs
  const [heightCm, setHeightCm] = useState<string>('175');
  const [weightKg, setWeightKg] = useState<string>('70');

  // Imperial inputs
  const [heightFt, setHeightFt] = useState<string>('5');
  const [heightIn, setHeightIn] = useState<string>('9');
  const [weightLbs, setWeightLbs] = useState<string>('154');

  // Activity level for TDEE calories
  const [activity, setActivity] = useState<number>(1.375); // Light exercise
  const [copied, setCopied] = useState(false);

  // Sync when toggling units
  const handleUnitToggle = (newUnit: UnitSystem) => {
    if (newUnit === unit) return;
    if (newUnit === 'imperial') {
      const cm = parseFloat(heightCm) || 170;
      const totalInches = cm / 2.54;
      const ft = Math.floor(totalInches / 12);
      const inc = Math.round(totalInches % 12);
      setHeightFt(ft.toString());
      setHeightIn(inc.toString());

      const kg = parseFloat(weightKg) || 70;
      const lbs = Math.round(kg * 2.20462);
      setWeightLbs(lbs.toString());
    } else {
      const ft = parseFloat(heightFt) || 5;
      const inc = parseFloat(heightIn) || 8;
      const totalInches = ft * 12 + inc;
      const cm = Math.round(totalInches * 2.54);
      setHeightCm(cm.toString());

      const lbs = parseFloat(weightLbs) || 150;
      const kg = Math.round((lbs / 2.20462) * 10) / 10;
      setWeightKg(kg.toString());
    }
    setUnit(newUnit);
  };

  const results = useMemo(() => {
    let hMeters = 0;
    let wKg = 0;

    if (unit === 'metric') {
      const cm = parseFloat(heightCm) || 0;
      wKg = parseFloat(weightKg) || 0;
      hMeters = cm / 100;
    } else {
      const ft = parseFloat(heightFt) || 0;
      const inc = parseFloat(heightIn) || 0;
      const totalInches = ft * 12 + inc;
      hMeters = (totalInches * 2.54) / 100;
      wKg = (parseFloat(weightLbs) || 0) * 0.45359237;
    }

    if (hMeters <= 0 || wKg <= 0) return null;

    const bmi = wKg / (hMeters * hMeters);

    // WHO Classification
    let category = '';
    let categoryColor = '';
    let categoryAdvice = '';

    if (bmi < 16.0) {
      category = 'Severe Thinness';
      categoryColor = 'text-rose-600 bg-rose-50 border-rose-200';
      categoryAdvice = 'Significantly underweight. Consider consulting a nutritionist.';
    } else if (bmi < 17.0) {
      category = 'Moderate Thinness';
      categoryColor = 'text-amber-600 bg-amber-50 border-amber-200';
      categoryAdvice = 'Underweight. A nutrient-dense diet may be beneficial.';
    } else if (bmi < 18.5) {
      category = 'Mild Thinness';
      categoryColor = 'text-amber-600 bg-amber-50 border-amber-200';
      categoryAdvice = 'Slightly underweight.';
    } else if (bmi < 25.0) {
      category = 'Normal Weight';
      categoryColor = 'text-emerald-700 bg-emerald-50 border-emerald-200';
      categoryAdvice = 'Great! Your BMI is in the healthy range recommended by WHO.';
    } else if (bmi < 30.0) {
      category = 'Overweight';
      categoryColor = 'text-amber-700 bg-amber-50 border-amber-200';
      categoryAdvice = 'Above recommended weight range. Balanced exercise and diet can help.';
    } else if (bmi < 35.0) {
      category = 'Obese Class I';
      categoryColor = 'text-orange-600 bg-orange-50 border-orange-200';
      categoryAdvice = 'High health risk. Lifestyle adjustments are recommended.';
    } else if (bmi < 40.0) {
      category = 'Obese Class II';
      categoryColor = 'text-rose-600 bg-rose-50 border-rose-200';
      categoryAdvice = 'Very high health risk.';
    } else {
      category = 'Obese Class III';
      categoryColor = 'text-rose-700 bg-rose-100 border-rose-300';
      categoryAdvice = 'Extremely high health risk.';
    }

    // Healthy weight range (BMI 18.5 to 24.9)
    const minHealthyKg = 18.5 * (hMeters * hMeters);
    const maxHealthyKg = 24.9 * (hMeters * hMeters);

    let weightDeltaKg = 0;
    let weightDeltaText = '';

    if (bmi < 18.5) {
      weightDeltaKg = minHealthyKg - wKg;
      weightDeltaText = `Gain at least ${formatNumber(weightDeltaKg, 1)} kg to reach normal BMI`;
    } else if (bmi > 24.9) {
      weightDeltaKg = wKg - maxHealthyKg;
      weightDeltaText = `Lose at least ${formatNumber(weightDeltaKg, 1)} kg to reach normal BMI`;
    } else {
      weightDeltaText = 'You are already inside the healthy weight range';
    }

    // BMR calculation (Mifflin-St Jeor formula)
    const ageNum = parseInt(age) || 28;
    const heightInCm = hMeters * 100;
    let bmr = 10 * wKg + 6.25 * heightInCm - 5 * ageNum;
    if (gender === 'male') {
      bmr += 5;
    } else {
      bmr -= 161;
    }

    const tdee = Math.round(bmr * activity);

    // Spectrum bar position (min 15 to max 40 mapped to 0% - 100%)
    const clampedBmi = Math.min(Math.max(bmi, 15), 40);
    const gaugePercent = ((clampedBmi - 15) / (40 - 15)) * 100;

    return {
      bmi,
      category,
      categoryColor,
      categoryAdvice,
      minHealthyKg,
      maxHealthyKg,
      weightDeltaText,
      bmr: Math.round(bmr),
      tdee,
      gaugePercent,
      hMeters,
      wKg,
    };
  }, [unit, gender, age, heightCm, weightKg, heightFt, heightIn, weightLbs, activity]);

  const handleCopy = async () => {
    if (!results) return;
    const text = `BMI: ${formatNumber(results.bmi, 1)} (${results.category})\n` +
      `Healthy Weight: ${formatNumber(results.minHealthyKg, 1)}kg - ${formatNumber(results.maxHealthyKg, 1)}kg\n` +
      `BMR: ${results.bmr} kcal/day · Maintenance: ${results.tdee} kcal/day`;
    const success = await copyToClipboard(text);
    if (success) {
      setCopied(true);
      showToast('BMI results copied');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleSaveHistory = () => {
    if (!results) return;
    addHistory({
      calculatorId: 'bmi',
      calculatorName: 'BMI Calculator',
      summary: `BMI: ${formatNumber(results.bmi, 1)} (${results.category})`,
      details: `${results.weightDeltaText} · BMR: ${results.bmr} kcal · TDEE: ${results.tdee} kcal`,
    });
    showToast('Saved to Activity Log');
  };

  return (
    <div className="space-y-6">
      {/* Title */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight text-slate-900">BMI Calculator</h1>
        <div className="flex items-center gap-2 text-xs text-slate-500 mt-1">
          <span>WHO Body Mass Index</span>
          <span aria-hidden="true">·</span>
          <span>Target Weight Range</span>
          <span aria-hidden="true">·</span>
          <span>BMR & Daily Maintenance Calories</span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Form */}
        <div className="lg:col-span-7 bg-white rounded-xl border border-slate-200/90 p-5 sm:p-6 space-y-5">
          {/* Unit Toggle & Gender */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Unit System
              </label>
              <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => handleUnitToggle('metric')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    unit === 'metric' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  Metric (cm / kg)
                </button>
                <button
                  type="button"
                  onClick={() => handleUnitToggle('imperial')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    unit === 'imperial' ? 'bg-white text-indigo-700 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  Imperial (ft-in / lbs)
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Gender (for BMR)
              </label>
              <div className="flex gap-1 p-1 bg-slate-100 rounded-lg">
                <button
                  type="button"
                  onClick={() => setGender('male')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    gender === 'male' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  Male
                </button>
                <button
                  type="button"
                  onClick={() => setGender('female')}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors cursor-pointer ${
                    gender === 'female' ? 'bg-white text-slate-900 shadow-2xs' : 'text-slate-600'
                  }`}
                >
                  Female
                </button>
              </div>
            </div>
          </div>

          {/* Height and Weight Inputs */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {unit === 'metric' ? (
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Height (cm)
                </label>
                <div className="relative">
                  <input
                    type="number"
                    value={heightCm}
                    onChange={(e) => setHeightCm(e.target.value)}
                    className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                  />
                  <span className="absolute right-3 top-2.5 text-slate-400 font-mono text-xs">cm</span>
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                  Height (Feet & Inches)
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <div className="relative">
                    <input
                      type="number"
                      value={heightFt}
                      onChange={(e) => setHeightFt(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                    />
                    <span className="absolute right-3 top-2 text-slate-400 font-mono text-xs">ft</span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      value={heightIn}
                      onChange={(e) => setHeightIn(e.target.value)}
                      className="w-full px-3 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
                    />
                    <span className="absolute right-3 top-2 text-slate-400 font-mono text-xs">in</span>
                  </div>
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Weight ({unit === 'metric' ? 'kg' : 'lbs'})
              </label>
              <div className="relative">
                <input
                  type="number"
                  step="any"
                  value={unit === 'metric' ? weightKg : weightLbs}
                  onChange={(e) => (unit === 'metric' ? setWeightKg(e.target.value) : setWeightLbs(e.target.value))}
                  className="w-full px-3.5 py-2.5 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:bg-white"
                />
                <span className="absolute right-3 top-2.5 text-slate-400 font-mono text-xs">
                  {unit === 'metric' ? 'kg' : 'lbs'}
                </span>
              </div>
            </div>
          </div>

          {/* Age & Activity Level */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Age (years)
              </label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full px-3.5 py-2 text-sm font-semibold font-mono text-slate-900 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-wider mb-1.5">
                Activity Level
              </label>
              <select
                value={activity}
                onChange={(e) => setActivity(parseFloat(e.target.value))}
                className="w-full px-3 py-2 text-xs font-medium text-slate-700 bg-slate-50 border border-slate-300 rounded-lg focus:outline-none"
              >
                <option value={1.2}>Sedentary (Little or no exercise)</option>
                <option value={1.375}>Lightly active (1-3 days/week)</option>
                <option value={1.55}>Moderately active (3-5 days/week)</option>
                <option value={1.725}>Very active (6-7 days/week)</option>
                <option value={1.9}>Extra active (Physical job / 2x training)</option>
              </select>
            </div>
          </div>
        </div>

        {/* Right Output Panel */}
        <div className="lg:col-span-5 space-y-4">
          {results && (
            <div className="bg-white rounded-xl border border-slate-200/90 p-6 space-y-5">
              {/* BMI Big Stat */}
              <div>
                <div className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1">
                  Your Body Mass Index (BMI)
                </div>
                <div className="flex items-baseline gap-3">
                  <span className="text-4xl font-extrabold font-mono tabular-nums text-slate-900">
                    {formatNumber(results.bmi, 1)}
                  </span>
                  <span className={`px-2.5 py-1 text-xs font-bold rounded-md border ${results.categoryColor}`}>
                    {results.category}
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-2">{results.categoryAdvice}</p>
              </div>

              {/* Visual Linear Gauge */}
              <div className="space-y-1.5 pt-2">
                <div className="flex justify-between text-[11px] font-mono text-slate-400">
                  <span>Underweight (&lt;18.5)</span>
                  <span>Normal (18.5-24.9)</span>
                  <span>Overweight (25-30)</span>
                  <span>Obese (30+)</span>
                </div>
                <div className="relative h-3 w-full bg-slate-100 rounded-full overflow-hidden flex">
                  <div className="w-[14%] bg-amber-300" title="Underweight" />
                  <div className="w-[36%] bg-emerald-500" title="Normal" />
                  <div className="w-[20%] bg-amber-500" title="Overweight" />
                  <div className="w-[30%] bg-rose-500" title="Obese" />
                </div>
                {/* Pointer indicator */}
                <div className="relative w-full h-3">
                  <div
                    className="absolute -top-1 -translate-x-1/2 w-0 h-0 border-x-4 border-x-transparent border-b-6 border-b-slate-900"
                    style={{ left: `${results.gaugePercent}%` }}
                  />
                </div>
              </div>

              {/* Target & Advice Box */}
              <div className="p-3.5 bg-slate-50 rounded-lg border border-slate-200/80 text-xs space-y-2">
                <div className="flex items-center gap-1.5 font-semibold text-slate-800">
                  <Heart className="w-3.5 h-3.5 text-rose-500" />
                  <span>Healthy Weight Target for Your Height</span>
                </div>
                <div className="font-mono text-slate-700">
                  {unit === 'metric' ? (
                    <>
                      <strong>{formatNumber(results.minHealthyKg, 1)} kg</strong> &ndash;{' '}
                      <strong>{formatNumber(results.maxHealthyKg, 1)} kg</strong>
                    </>
                  ) : (
                    <>
                      <strong>{formatNumber(results.minHealthyKg * 2.20462, 1)} lbs</strong> &ndash;{' '}
                      <strong>{formatNumber(results.maxHealthyKg * 2.20462, 1)} lbs</strong>
                    </>
                  )}
                </div>
                <div className="text-[11px] text-slate-500">{results.weightDeltaText}</div>
              </div>

              {/* BMR & Calorie Estimates */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                  <div className="text-slate-400 font-medium">BMR (Basal Rate)</div>
                  <div className="text-lg font-bold font-mono text-slate-900 mt-0.5">
                    {results.bmr} <span className="text-[10px] text-slate-500 font-normal">kcal/day</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">At complete rest</div>
                </div>

                <div className="p-3 bg-slate-50 rounded-lg border border-slate-200/60">
                  <div className="text-slate-400 font-medium flex items-center gap-1">
                    <Flame className="w-3 h-3 text-amber-500" />
                    <span>Daily Maintenance</span>
                  </div>
                  <div className="text-lg font-bold font-mono text-indigo-700 mt-0.5">
                    {results.tdee} <span className="text-[10px] text-slate-500 font-normal">kcal/day</span>
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">With selected activity</div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="flex-1 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied' : 'Copy Report'}</span>
                </button>
                <button
                  onClick={handleSaveHistory}
                  className="flex-1 py-2 text-xs font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Bookmark className="w-3.5 h-3.5" />
                  <span>Save</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
