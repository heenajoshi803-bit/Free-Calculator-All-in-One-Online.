import React from 'react';
import { useCalc } from '../context/CalcContext';
import { CALCULATOR_REGISTRY } from '../data/calculatorRegistry';
import { CalculatorId } from '../types/calculators';
import {
  Cake,
  Percent,
  Tag,
  Receipt,
  Activity,
  Calculator,
  Landmark,
  Calendar,
  FileText,
  Dices,
  X,
  Search,
} from 'lucide-react';

const ICON_MAP: Record<string, React.ElementType> = {
  Cake,
  Percent,
  Tag,
  Receipt,
  Activity,
  Calculator,
  Landmark,
  Calendar,
  FileText,
  Dices,
};

export const Sidebar: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    isMobileSidebarOpen,
    setIsMobileSidebarOpen,
    setIsSearchOpen,
  } = useCalc();

  const handleSelect = (id: CalculatorId) => {
    setActiveTab(id);
    setIsMobileSidebarOpen(false);
  };

  const navContent = (
    <div className="flex flex-col h-full">
      {/* Top Search trigger in sidebar */}
      <div className="p-4 border-b border-slate-200/80">
        <button
          onClick={() => {
            setIsMobileSidebarOpen(false);
            setIsSearchOpen(true);
          }}
          className="w-full flex items-center justify-between px-3 py-2 text-xs text-slate-500 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors text-left"
        >
          <div className="flex items-center gap-2">
            <Search className="w-3.5 h-3.5 text-slate-400" />
            <span>Search 10 calculators...</span>
          </div>
          <kbd className="text-[10px] font-mono bg-white px-1.5 py-0.5 border border-slate-200 rounded">
            ⌘K
          </kbd>
        </button>
      </div>

      {/* Navigation list */}
      <div className="flex-1 overflow-y-auto p-3 space-y-1">
        <div className="px-3 py-1.5 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
          Calculators Suite
        </div>

        {CALCULATOR_REGISTRY.map((calc, index) => {
          const Icon = ICON_MAP[calc.iconName] || Calculator;
          const isActive = activeTab === calc.id;

          return (
            <button
              key={calc.id}
              onClick={() => handleSelect(calc.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 text-sm font-medium rounded-lg transition-all text-left group ${
                isActive
                  ? 'bg-indigo-600 text-white shadow-sm shadow-indigo-200 font-semibold'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
              }`}
            >
              <div
                className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 transition-colors ${
                  isActive
                    ? 'bg-white/20 text-white'
                    : 'bg-slate-100 text-slate-600 group-hover:bg-slate-200 group-hover:text-slate-900'
                }`}
              >
                <Icon className="w-4 h-4" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="flex items-center justify-between">
                  <span className="truncate">{calc.name}</span>
                  <span
                    className={`text-[10px] font-mono tabular-nums ${
                      isActive ? 'text-indigo-200' : 'text-slate-400'
                    }`}
                  >
                    {String(index + 1).padStart(2, '0')}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Sidebar Footer info */}
      <div className="p-4 border-t border-slate-200/80 bg-slate-50/50">
        <div className="text-xs text-slate-500 space-y-1">
          <div className="font-medium text-slate-700">100% Client-Side</div>
          <div className="text-[11px] text-slate-400">
            Instant calculations · Zero API calls · Private & offline-ready
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop Persistent Sidebar */}
      <aside className="hidden lg:block w-72 shrink-0 border-r border-slate-200/80 bg-white min-h-[calc(100vh-4rem)]">
        <div className="sticky top-16 h-[calc(100vh-4rem)]">
          {navContent}
        </div>
      </aside>

      {/* Mobile Drawer Overlay */}
      {isMobileSidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
            onClick={() => setIsMobileSidebarOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-72 max-w-[85vw] bg-white shadow-xl flex flex-col z-10 animate-in slide-in-from-left duration-200">
            <div className="p-4 border-b border-slate-200 flex items-center justify-between">
              <span className="font-bold text-slate-900">Select Calculator</span>
              <button
                onClick={() => setIsMobileSidebarOpen(false)}
                className="p-1.5 text-slate-500 hover:text-slate-800 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {navContent}
            </div>
          </div>
        </div>
      )}
    </>
  );
};
