import React from 'react';
import { useCalc } from '../context/CalcContext';
import { CURRENCIES } from '../utils/formatters';
import { CurrencyCode } from '../types/calculators';
import { Search, History, Menu, Calculator } from 'lucide-react';

export const Header: React.FC = () => {
  const {
    currency,
    setCurrency,
    setIsSearchOpen,
    setIsHistoryOpen,
    setIsMobileSidebarOpen,
    history,
  } = useCalc();

  return (
    <header className="sticky top-0 z-30 h-16 w-full border-b border-slate-200/80 bg-white/90 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between transition-colors">
      {/* Zone 1: Brand title, one line */}
      <div className="flex items-center gap-3">
        <button
          onClick={() => setIsMobileSidebarOpen(true)}
          className="lg:hidden p-2 -ml-2 text-slate-600 hover:text-slate-900 rounded-lg hover:bg-slate-100 transition-colors"
          aria-label="Open menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <a href="/" className="flex items-center gap-2.5 text-slate-900 focus:outline-none">
          <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-sm shadow-indigo-200">
            <Calculator className="w-4 h-4" />
          </div>
          <span className="text-base sm:text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap">
            Free Calculator <span className="text-sm font-normal text-slate-400 hidden sm:inline">– All-in-One Online</span>
          </span>
        </a>
      </div>

      {/* Zone 2: Navigation Links / Fast Category Jumps */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
        <button
          onClick={() => setIsSearchOpen(true)}
          className="hover:text-slate-900 transition-colors cursor-pointer"
        >
          All 10 Tools
        </button>
        <span className="text-slate-300">·</span>
        <button
          onClick={() => setIsHistoryOpen(true)}
          className="hover:text-slate-900 transition-colors cursor-pointer flex items-center gap-1.5"
        >
          <span>Activity Log</span>
          {history.length > 0 && (
            <span className="text-xs font-mono text-indigo-600 font-semibold">({history.length})</span>
          )}
        </button>
      </nav>

      {/* Zone 3: Primary Actions */}
      <div className="flex items-center gap-2 sm:gap-3">
        {/* Currency Switcher */}
        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium bg-slate-100 hover:bg-slate-200/70 py-1.5 px-2.5 rounded-lg border border-slate-200/60 transition-colors">
          <span className="hidden sm:inline">Currency:</span>
          <select
            value={currency}
            onChange={(e) => setCurrency(e.target.value as CurrencyCode)}
            className="bg-transparent font-semibold text-slate-800 focus:outline-none cursor-pointer text-xs"
            aria-label="Select preferred currency"
          >
            {Object.values(CURRENCIES).map((c) => (
              <option key={c.code} value={c.code}>
                {c.symbol} {c.code}
              </option>
            ))}
          </select>
        </div>

        {/* Quick Search Button */}
        <button
          onClick={() => setIsSearchOpen(true)}
          className="flex items-center gap-2 px-3 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 bg-slate-100 hover:bg-slate-200/70 border border-slate-200/60 rounded-lg transition-colors whitespace-nowrap"
          title="Search calculators (Cmd+K)"
        >
          <Search className="w-3.5 h-3.5 text-slate-500" />
          <span className="hidden sm:inline">Search</span>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-slate-500 bg-white border border-slate-200 rounded">
            ⌘K
          </kbd>
        </button>

        {/* History Modal Trigger */}
        <button
          onClick={() => setIsHistoryOpen(true)}
          className="relative p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 border border-transparent hover:border-slate-200 rounded-lg transition-colors"
          title="View recent calculations history"
          aria-label="View history"
        >
          <History className="w-4 h-4" />
          {history.length > 0 && (
            <span className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full bg-indigo-600 ring-2 ring-white" />
          )}
        </button>
      </div>
    </header>
  );
};
