import React from 'react';
import { useCalc } from '../context/CalcContext';
import { X, Trash2, Copy, Clock, ExternalLink } from 'lucide-react';
import { copyToClipboard } from '../utils/formatters';

export const HistoryModal: React.FC = () => {
  const {
    isHistoryOpen,
    setIsHistoryOpen,
    history,
    clearHistory,
    deleteHistoryItem,
    setActiveTab,
    showToast,
  } = useCalc();

  if (!isHistoryOpen) return null;

  const handleCopy = async (text: string) => {
    const success = await copyToClipboard(text);
    if (success) showToast('Copied calculation to clipboard');
  };

  const handleOpenCalc = (calcId: any) => {
    setActiveTab(calcId);
    setIsHistoryOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-white rounded-xl shadow-2xl border border-slate-200 w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 border-b border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <Clock className="w-5 h-5 text-indigo-600" />
            <h2 className="text-base font-semibold text-slate-900">Activity & Calculation History</h2>
          </div>
          <div className="flex items-center gap-2">
            {history.length > 0 && (
              <button
                onClick={clearHistory}
                className="text-xs text-rose-600 hover:text-rose-700 font-medium px-2.5 py-1 hover:bg-rose-50 rounded-md transition-colors flex items-center gap-1"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear All
              </button>
            )}
            <button
              onClick={() => setIsHistoryOpen(false)}
              className="p-1.5 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-3">
          {history.length === 0 ? (
            <div className="text-center py-12">
              <Clock className="w-10 h-10 text-slate-300 mx-auto mb-3 stroke-[1.5]" />
              <p className="text-sm font-medium text-slate-700">No calculation history yet</p>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Calculations you perform across any of the 10 tools will automatically appear here for quick reference and copying.
              </p>
            </div>
          ) : (
            history.map((item) => (
              <div
                key={item.id}
                className="p-4 rounded-lg border border-slate-200/90 bg-slate-50/50 hover:bg-slate-50 transition-colors group flex items-start justify-between gap-4"
              >
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 text-xs text-slate-500 mb-1">
                    <button
                      onClick={() => handleOpenCalc(item.calculatorId)}
                      className="font-medium text-indigo-600 hover:text-indigo-700 hover:underline flex items-center gap-1"
                    >
                      {item.calculatorName}
                      <ExternalLink className="w-3 h-3" />
                    </button>
                    <span aria-hidden="true">·</span>
                    <span className="font-mono tabular-nums">
                      {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                    <span aria-hidden="true">·</span>
                    <span>{new Date(item.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric' })}</span>
                  </div>
                  <div className="font-semibold text-slate-900 text-sm">{item.summary}</div>
                  {item.details && (
                    <div className="text-xs text-slate-600 mt-1 font-mono tabular-nums whitespace-pre-line leading-relaxed">
                      {item.details}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0 pt-1">
                  <button
                    onClick={() => handleCopy(`${item.calculatorName}: ${item.summary}\n${item.details}`)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-md transition-colors"
                    title="Copy details"
                  >
                    <Copy className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => deleteHistoryItem(item.id)}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-colors"
                    title="Delete item"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-slate-200 bg-slate-50 text-xs text-slate-500 flex justify-between items-center">
          <span>Stored locally in your browser</span>
          <button
            onClick={() => setIsHistoryOpen(false)}
            className="px-3 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 font-medium rounded-md transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
