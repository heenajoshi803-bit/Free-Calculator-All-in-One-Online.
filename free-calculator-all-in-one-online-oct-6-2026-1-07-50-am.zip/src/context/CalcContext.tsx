import React, { createContext, useContext, useState, useEffect } from 'react';
import { CalculatorId, CalculationHistoryItem, CurrencyCode } from '../types/calculators';

interface CalcContextType {
  activeTab: CalculatorId;
  setActiveTab: (tab: CalculatorId) => void;
  currency: CurrencyCode;
  setCurrency: (c: CurrencyCode) => void;
  history: CalculationHistoryItem[];
  addHistory: (item: Omit<CalculationHistoryItem, 'id' | 'timestamp'>) => void;
  clearHistory: () => void;
  deleteHistoryItem: (id: string) => void;
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isHistoryOpen: boolean;
  setIsHistoryOpen: (open: boolean) => void;
  isMobileSidebarOpen: boolean;
  setIsMobileSidebarOpen: (open: boolean) => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;
}

const CalcContext = createContext<CalcContextType | undefined>(undefined);

const HISTORY_STORAGE_KEY = 'omnicalc_history_v1';
const CURRENCY_STORAGE_KEY = 'omnicalc_currency_v1';
const TAB_STORAGE_KEY = 'omnicalc_active_tab_v1';

export const CalcProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [activeTab, setActiveTabState] = useState<CalculatorId>(() => {
    const saved = localStorage.getItem(TAB_STORAGE_KEY);
    return (saved as CalculatorId) || 'age';
  });

  const [currency, setCurrencyState] = useState<CurrencyCode>(() => {
    const saved = localStorage.getItem(CURRENCY_STORAGE_KEY);
    return (saved as CurrencyCode) || 'USD';
  });

  const [history, setHistory] = useState<CalculationHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem(HISTORY_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState(false);
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const setActiveTab = (tab: CalculatorId) => {
    setActiveTabState(tab);
    localStorage.setItem(TAB_STORAGE_KEY, tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const setCurrency = (c: CurrencyCode) => {
    setCurrencyState(c);
    localStorage.setItem(CURRENCY_STORAGE_KEY, c);
  };

  const addHistory = (item: Omit<CalculationHistoryItem, 'id' | 'timestamp'>) => {
    const newItem: CalculationHistoryItem = {
      ...item,
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      timestamp: Date.now(),
    };
    setHistory((prev) => {
      // Don't add duplicate if summary is identical to most recent entry
      if (prev.length > 0 && prev[0].summary === newItem.summary && prev[0].calculatorId === newItem.calculatorId) {
        return prev;
      }
      const updated = [newItem, ...prev.slice(0, 49)]; // Keep latest 50
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem(HISTORY_STORAGE_KEY);
  };

  const deleteHistoryItem = (id: string) => {
    setHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(updated));
      return updated;
    });
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  useEffect(() => {
    if (!toastMessage) return;
    const timer = setTimeout(() => {
      setToastMessage(null);
    }, 2500);
    return () => clearTimeout(timer);
  }, [toastMessage]);

  // Global keyboard shortcut: Cmd+K / Ctrl+K opens quick search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchOpen(true);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <CalcContext.Provider
      value={{
        activeTab,
        setActiveTab,
        currency,
        setCurrency,
        history,
        addHistory,
        clearHistory,
        deleteHistoryItem,
        isSearchOpen,
        setIsSearchOpen,
        isHistoryOpen,
        setIsHistoryOpen,
        isMobileSidebarOpen,
        setIsMobileSidebarOpen,
        toastMessage,
        showToast,
      }}
    >
      {children}
    </CalcContext.Provider>
  );
};

export const useCalc = () => {
  const context = useContext(CalcContext);
  if (!context) {
    throw new Error('useCalc must be used within a CalcProvider');
  }
  return context;
};
