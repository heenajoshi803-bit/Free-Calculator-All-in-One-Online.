export type CalculatorId =
  | 'age'
  | 'percentage'
  | 'discount'
  | 'gst'
  | 'bmi'
  | 'emi'
  | 'loan'
  | 'date-diff'
  | 'word-counter'
  | 'random-gen';

export type Category = 'Finance' | 'Math & Everyday' | 'Health' | 'Date & Time' | 'Text & Utilities';

export interface CalculatorMeta {
  id: CalculatorId;
  name: string;
  shortName: string;
  category: Category;
  description: string;
  iconName: string;
  keywords: string[];
}

export interface CalculationHistoryItem {
  id: string;
  calculatorId: CalculatorId;
  calculatorName: string;
  summary: string;
  details: string;
  timestamp: number;
}

export type CurrencyCode = 'USD' | 'INR' | 'EUR' | 'GBP' | 'CAD' | 'AUD' | 'JPY';

export interface CurrencyConfig {
  code: CurrencyCode;
  symbol: string;
  name: string;
  locale: string;
}
