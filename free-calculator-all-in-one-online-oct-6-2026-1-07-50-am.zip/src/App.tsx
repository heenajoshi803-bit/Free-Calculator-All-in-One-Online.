import React from 'react';
import { CalcProvider, useCalc } from './context/CalcContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { HistoryModal } from './components/HistoryModal';
import { QuickSearchModal } from './components/QuickSearchModal';

// Calculators
import { AgeCalculator } from './components/calculators/AgeCalculator';
import { PercentageCalculator } from './components/calculators/PercentageCalculator';
import { DiscountCalculator } from './components/calculators/DiscountCalculator';
import { GstCalculator } from './components/calculators/GstCalculator';
import { BmiCalculator } from './components/calculators/BmiCalculator';
import { EmiCalculator } from './components/calculators/EmiCalculator';
import { LoanCalculator } from './components/calculators/LoanCalculator';
import { DateDifferenceCalculator } from './components/calculators/DateDifferenceCalculator';
import { WordCounter } from './components/calculators/WordCounter';
import { RandomNumberGenerator } from './components/calculators/RandomNumberGenerator';

const CalculatorRenderer: React.FC = () => {
  const { activeTab, toastMessage } = useCalc();

  return (
    <div className="flex-1 flex flex-col min-w-0">
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto">
        {activeTab === 'age' && <AgeCalculator />}
        {activeTab === 'percentage' && <PercentageCalculator />}
        {activeTab === 'discount' && <DiscountCalculator />}
        {activeTab === 'gst' && <GstCalculator />}
        {activeTab === 'bmi' && <BmiCalculator />}
        {activeTab === 'emi' && <EmiCalculator />}
        {activeTab === 'loan' && <LoanCalculator />}
        {activeTab === 'date-diff' && <DateDifferenceCalculator />}
        {activeTab === 'word-counter' && <WordCounter />}
        {activeTab === 'random-gen' && <RandomNumberGenerator />}
      </main>

      {/* Global Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-lg shadow-xl border border-slate-700 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>{toastMessage}</span>
          </div>
        </div>
      )}

      {/* Quiet Footer */}
      <footer className="border-t border-slate-200/80 bg-white py-6 px-4 sm:px-8 mt-12">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-slate-700">Free Calculator – All-in-One Online</span>
            <span aria-hidden="true">·</span>
            <span>10 Fast Tools</span>
            <span aria-hidden="true">·</span>
            <span>Zero API Calls</span>
          </div>
          <div>All calculations performed instantly in your browser</div>
        </div>
      </footer>
    </div>
  );
};

export default function App() {
  return (
    <CalcProvider>
      <div className="min-h-screen bg-slate-50 flex flex-col antialiased">
        <Header />
        <div className="flex-1 flex w-full">
          <Sidebar />
          <CalculatorRenderer />
        </div>
        <HistoryModal />
        <QuickSearchModal />
      </div>
    </CalcProvider>
  );
}
